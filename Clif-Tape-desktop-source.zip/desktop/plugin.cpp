// Desktop host adapter: exposes only functional controls, using the same DSP/state.
#define VSTPluginMain ClifForceMain
#include "../src/plugin.cpp"
#undef VSTPluginMain
namespace desktop {
constexpr int map[]={P_classic,MODEL_SELECT,DRIVE,P_failure,P_wow,P_flutter,P_spread,P_miso,P_crinkle,NOISE_SOUND,P_hiss,MECH_SOUND,P_mechanical,SILENCE_GATE,FADE_IN,FADE_OUT,P_mix,P_volume};
constexpr int count=sizeof(map)/sizeof(map[0]);
struct Host {audioMasterCallback callback;decltype(AEffect::dispatcher) dispatch;decltype(AEffect::setParameter) set;decltype(AEffect::getParameter) get;};
Host* h(AEffect* e){return static_cast<Host*>(e->user);}
intptr_t notify(AEffect*e,int32_t op,int32_t i,intptr_t v,void*p,float f){if(!e||!h(e))return op==1?2400:0; if(op==0){int n=-1;for(int k=0;k<count;++k)if(map[k]==i)n=k;if(n<0)return 0;i=n;}return h(e)->callback?h(e)->callback(e,op,i,v,p,f):0;}
void setParam(AEffect*e,int32_t i,float v){if(i>=0&&i<count)h(e)->set(e,map[i],v);}
float getParam(AEffect*e,int32_t i){return i>=0&&i<count?h(e)->get(e,map[i]):0;}
intptr_t dispatch(AEffect*e,int32_t op,int32_t i,intptr_t v,void*p,float f){auto*host=h(e);if(op==1){auto fn=host->dispatch;e->user=nullptr;delete host;return fn(e,op,i,v,p,f);}if(op==6||op==7||op==8||op==26){if(i<0||i>=count)return 0;i=map[i];}return host->dispatch(e,op,i,v,p,f);}
}
#if defined(_WIN32)
#define CLIF_EXPORT __declspec(dllexport)
#else
#define CLIF_EXPORT __attribute__((visibility("default")))
#endif
extern "C" CLIF_EXPORT AEffect* VSTPluginMain(audioMasterCallback callback){auto*e=ClifForceMain(desktop::notify);if(!e)return nullptr;auto*h=new(std::nothrow) desktop::Host{callback,e->dispatcher,e->setParameter,e->getParameter};if(!h){e->dispatcher(e,1,0,0,nullptr,0);return nullptr;}e->user=h;e->dispatcher=desktop::dispatch;e->setParameter=desktop::setParam;e->getParameter=desktop::getParam;e->numParams=desktop::count;e->uniqueID=0x436c5450;return e;}
