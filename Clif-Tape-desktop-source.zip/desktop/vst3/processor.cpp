#include "plugin.h"
#include "pluginterfaces/vst/ivstparameterchanges.h"
#include <algorithm>
#include <cmath>
#include <cstring>
namespace ClifTape {
Processor::Processor(){setControllerClass(ControllerID);effect=VSTPluginMain(nullptr);if(effect)effect->dispatcher(effect,0,0,0,nullptr,0);}
Processor::~Processor(){if(effect)effect->dispatcher(effect,1,0,0,nullptr,0);}
tresult PLUGIN_API Processor::initialize(FUnknown*c){auto r=AudioEffect::initialize(c);if(r!=kResultOk)return r;if(!effect)return kResultFalse;addAudioInput(STR16("Stereo In"),SpeakerArr::kStereo);addAudioOutput(STR16("Stereo Out"),SpeakerArr::kStereo);addEventInput(STR16("MIDI Controls"),1);return kResultOk;}
tresult PLUGIN_API Processor::setActive(TBool active){effect->dispatcher(effect,12,0,active?1:0,nullptr,0);return AudioEffect::setActive(active);}
tresult PLUGIN_API Processor::setupProcessing(ProcessSetup&s){if(s.sampleRate<8000||s.sampleRate>192000)return kResultFalse;effect->dispatcher(effect,10,0,0,nullptr,float(s.sampleRate));return AudioEffect::setupProcessing(s);}
tresult PLUGIN_API Processor::setBusArrangements(SpeakerArrangement*i,int32 ni,SpeakerArrangement*o,int32 no){return ni==1&&no==1&&i[0]==SpeakerArr::kStereo&&o[0]==SpeakerArr::kStereo?AudioEffect::setBusArrangements(i,ni,o,no):kResultFalse;}
tresult PLUGIN_API Processor::canProcessSampleSize(int32 s){return s==kSample32?kResultTrue:kResultFalse;}
uint32 PLUGIN_API Processor::getLatencySamples(){return effect?effect->initialDelay:0;}
tresult PLUGIN_API Processor::process(ProcessData&d){if(!effect||d.symbolicSampleSize!=kSample32)return kResultFalse;
 // Apply queued automation even for zero-sample parameter flushes.
 if(d.inputParameterChanges)for(int32 q=0;q<d.inputParameterChanges->getParameterCount();++q){auto*p=d.inputParameterChanges->getParameterData(q);if(!p||p->getParameterId()>=Count)continue;int32 offset;ParamValue v;if(p->getPoint(p->getPointCount()-1,offset,v)==kResultTrue&&std::isfinite(v))effect->setParameter(effect,p->getParameterId(),float(std::clamp(v,0.,1.)));}
 if(d.numSamples<=0)return kResultOk;if(d.numInputs!=1||d.numOutputs!=1||d.inputs[0].numChannels!=2||d.outputs[0].numChannels!=2)return kResultFalse;
 effect->processReplacing(effect,d.inputs[0].channelBuffers32,d.outputs[0].channelBuffers32,d.numSamples);d.outputs[0].silenceFlags=0;return kResultOk;}
tresult PLUGIN_API Processor::getState(IBStream*s){if(!s)return kResultFalse;void*p=nullptr;int32 n=int32(effect->dispatcher(effect,23,0,0,&p,0)),w=0;return n==128&&s->write(p,n,&w)==kResultOk&&w==n?kResultOk:kResultFalse;}
tresult PLUGIN_API Processor::setState(IBStream*s){if(!s)return kResultFalse;char b[128];int32 n=0;if(s->read(b,128,&n)!=kResultOk||n!=128)return kResultFalse;return effect->dispatcher(effect,24,0,128,b,0)?kResultOk:kResultFalse;}
}
