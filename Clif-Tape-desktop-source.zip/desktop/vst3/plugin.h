#pragma once
#include "public.sdk/source/vst/vstaudioeffect.h"
#include "public.sdk/source/vst/vsteditcontroller.h"
#include "pluginterfaces/vst/ivstmidicontrollers.h"
#include "pluginterfaces/base/ibstream.h"
#include "vstgui4/vstgui/plugin-bindings/vst3editor.h"
#include "pluginterfaces/base/ustring.h"
#include "../../src/vst2.hpp"
#include <array>
extern "C" AEffect* VSTPluginMain(audioMasterCallback);
namespace ClifTape {
using namespace Steinberg;using namespace Steinberg::Vst;
const FUID ProcessorID(0x434c5441,0x50453032,0xA36FA95B,0x382F7110),ControllerID(0x434c5441,0x50453032,0xA36FA95B,0x382F7111);
constexpr int Count=18;
static const char* labels[]={"Tape / Digital","Model / Low-pass","Saturate / DEGRADE","Failure / High-pass","Wow","Flutter","Spread","Mono to Stereo","Crackle","Noise On","Noise Level","Mechanical On","Mechanical Texture","Silence Gate","Fade In","Fade Out","Mix","Volume"};
static const int steps[]={1,0,0,0,0,0,1,1,0,1,0,1,0,1,0,0,0,0};
class Processor final:public AudioEffect {
 AEffect* effect=nullptr;
public:
 Processor();~Processor()override;
 static FUnknown* createInstance(void*){return static_cast<IAudioProcessor*>(new Processor);}
 tresult PLUGIN_API initialize(FUnknown*)override;
 tresult PLUGIN_API setupProcessing(ProcessSetup&)override;
 tresult PLUGIN_API setBusArrangements(SpeakerArrangement*,int32,SpeakerArrangement*,int32)override;
 tresult PLUGIN_API canProcessSampleSize(int32)override;
 uint32 PLUGIN_API getLatencySamples()override;
 tresult PLUGIN_API process(ProcessData&)override;
 tresult PLUGIN_API getState(IBStream*)override;
 tresult PLUGIN_API setState(IBStream*)override;
};
class Controller final:public EditController,public IMidiMapping,public VSTGUI::VST3EditorDelegate {
public:
 static FUnknown* createInstance(void*){return static_cast<IEditController*>(new Controller);}
 tresult PLUGIN_API initialize(FUnknown*)override;
 tresult PLUGIN_API setComponentState(IBStream*)override;
 tresult PLUGIN_API getParamStringByValue(ParamID,ParamValue,String128)override;
 tresult PLUGIN_API getMidiControllerAssignment(int32,int16,CtrlNumber,ParamID&)override;
 IPlugView* PLUGIN_API createView(FIDString)override;
 VSTGUI::CView* createCustomView(VSTGUI::UTF8StringPtr,const VSTGUI::UIAttributes&,const VSTGUI::IUIDescription*,VSTGUI::VST3Editor*)override;
 void preset(int);
 OBJ_METHODS(Controller,EditController)
 DEFINE_INTERFACES
 DEF_INTERFACE(IMidiMapping)
 END_DEFINE_INTERFACES(EditController)
 REFCOUNT_METHODS(EditController)
};
}
