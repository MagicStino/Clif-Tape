#include "plugin.h"
#include "vstgui4/vstgui/lib/cbitmap.h"
#include "vstgui4/vstgui/lib/cdrawcontext.h"
#include "vstgui4/vstgui/lib/cfont.h"
#include <algorithm>
#include <cmath>
#include <cstring>
#include <string>
#include <vector>
namespace ClifTape {
using namespace VSTGUI;
struct Cell{int id;double x,y,r,w;const char*image;};
class Panel final:public CView{
 Controller*c;int page=0,editing=-1,program=0;double startY=0,startV=0;std::vector<Cell>cells;
 std::array<std::string,15> programNames;
 std::array<std::array<double,Count>,15> presetValues{};int matchedProgram=-1;
 SharedPointer<CBitmap> bg[5];std::array<double,Count> previous{};
 struct SwitchArt{const char*name;SharedPointer<CBitmap> off,on;};std::vector<SwitchArt>art;
 static constexpr double top=64;
 void text(CDrawContext*d,const std::string&s,CRect r,int size=24,CColor color=kBlackCColor){d->setFont(kNormalFont,size);d->setFontColor(color);d->drawString(s.c_str(),r,kCenterText);}
 std::string value(int id){String128 str{};c->getParamStringByValue(id,c->getParamNormalized(id),str);char b[128]{};UString(str,128).toAscii(b,sizeof b);return b;}
 void change(int id,double v){v=std::clamp(v,0.,1.);if(steps[id])v=std::round(v);if(id==1&&c->getParamNormalized(0)<.5)v=std::round(v*12)/12;c->setParamNormalized(id,v);c->performEdit(id,v);invalid();}
 bool disabled(int id){return (id==14||id==15)&&c->getParamNormalized(13)<.5;}
 void finish(){if(editing>=0){c->endEdit(editing);editing=-1;}}
 void refresh(){cells.clear();auto knob=[&](int id,double x,double y,double r){cells.push_back({id,x,y-86+top,r,0,nullptr});};auto sw=[&](int id,double x,double y,double w,const char*img){cells.push_back({id,x,y-86+top,32,w,img});};
 if(page==0){sw(0,1055,139,290,"classic");knob(1,216,332,58);knob(2,610,332,58);knob(3,1034,c->getParamNormalized(0)<.5?312:307,c->getParamNormalized(0)<.5?54:48);knob(8,928,480,42);sw(6,1140,480,144,"spread");}
 if(page==1){knob(4,230,362,58);knob(5,600,362,58);sw(7,1042,372,280,"miso");}
 if(page==2){knob(10,210,404,58);sw(9,475,404,136,"noise_sound");knob(12,835,404,58);sw(11,1100,404,136,"mech_sound");}
 if(page==3){cells.push_back({13,300,322+top,32,136,"noise_sound"});cells.push_back({14,650,320+top,42,0,nullptr});cells.push_back({15,1000,320+top,42,0,nullptr});}
 cells.push_back({16,400,552+top,28,590,nullptr});knob(17,1105,630,42);}
public:
 Panel(Controller*ctrl):CView(CRect(0,0,1280,692)),c(ctrl){const char*files[]={"tone.png","digital.png","motion.png","noise.png","gate.png"};for(int i=0;i<5;++i)bg[i]=VSTGUI::owned(new CBitmap(CResourceDescription(files[i])));for(auto n:{"classic","spread","miso","noise_sound","mech_sound"}){std::string a=std::string("switch-")+n;art.push_back({n,VSTGUI::owned(new CBitmap(CResourceDescription((a+"-0.png").c_str()))),VSTGUI::owned(new CBitmap(CResourceDescription((a+"-1.png").c_str())))});}auto*e=VSTPluginMain(nullptr);if(e){for(int i=0;i<15;++i){char b[24]{};e->dispatcher(e,29,i,0,b,0);programNames[i]=b;e->dispatcher(e,2,0,i,nullptr,0);for(int k=0;k<Count;++k)presetValues[i][k]=e->getParameter(e,k);}e->dispatcher(e,1,0,0,nullptr,0);}previous.fill(-1);refresh();setWantsIdle(true);}
 ~Panel()override{finish();}
 void onIdle()override{bool dirty=false;for(int i=0;i<Count;++i){double v=c->getParamNormalized(i);if(v!=previous[i]){previous[i]=v;dirty=true;}}if(dirty){matchedProgram=-1;for(int p=0;p<15;++p){bool match=true;for(int k=0;k<Count;++k)if(std::abs(previous[k]-presetValues[p][k])>0.00001)match=false;if(match){matchedProgram=p;program=p;break;}}refresh();invalid();}}
 void draw(CDrawContext*d)override{d->setDrawMode(kAntiAliasing);d->setFillColor(kBlackCColor);d->drawRect(getViewSize(),kDrawFilled);int b=page==0?(c->getParamNormalized(0)>=.5?1:0):page+1;bg[b]->draw(d,CRect(0,top,1280,top+628));const char*tab[]={"TONE","MOTION","TAPE NOISE","SILENCE GATE"};for(int i=0;i<4;++i){d->setFillColor(i==page?kWhiteCColor:CColor(35,35,35));d->drawRect(CRect(i*190+6,8,i*190+184,55),kDrawFilled);text(d,tab[i],CRect(i*190+6,8,i*190+184,55),22,i==page?kBlackCColor:kWhiteCColor);}text(d,"<",CRect(782,8,834,55),32,kWhiteCColor);text(d,programName(),CRect(838,8,1215,55),21,kWhiteCColor);text(d,">",CRect(1220,8,1275,55),32,kWhiteCColor);
 for(auto&a:cells){double v=c->getParamNormalized(a.id);if(a.image){for(auto&s:art)if(!std::strcmp(s.name,a.image)){auto bitmap=v>=.5?s.on:s.off;bitmap->draw(d,CRect(a.x-a.w/2,a.y-32,a.x+a.w/2,a.y+32));}continue;}
 if(a.id==16){d->setFillColor(kBlackCColor);d->drawEllipse(CRect(105,a.y-24,153,a.y+24),kDrawFilled);d->drawEllipse(CRect(647,a.y-24,695,a.y+24),kDrawFilled);d->drawRect(CRect(129,a.y-24,671,a.y+24),kDrawFilled);d->setFrameColor(kWhiteCColor);d->setLineWidth(5);d->drawLine(CPoint(111,a.y),CPoint(689,a.y));double x=129+542*v;d->setFillColor(kWhiteCColor);d->drawEllipse(CRect(x-24,a.y-22,x+24,a.y+22),kDrawFilled);d->setFillColor(kBlackCColor);d->drawRect(CRect(314,a.y+38,486,a.y+76),kDrawFilled);text(d,value(16),CRect(314,a.y+38,486,a.y+76),30,kWhiteCColor);continue;}
 d->setFillColor(disabled(a.id)?CColor(195,195,195):kWhiteCColor);d->setFrameColor(kBlackCColor);d->setLineWidth(2.5);d->drawEllipse(CRect(a.x-a.r,a.y-a.r,a.x+a.r,a.y+a.r),kDrawFilledAndStroked);d->setLineWidth(1);d->drawEllipse(CRect(a.x-a.r+9,a.y-a.r+9,a.x+a.r-9,a.y+a.r-9),kDrawStroked);double angle=(135+270*v)*3.141592653589793/180;d->setLineWidth(5);d->setFrameColor(disabled(a.id)?CColor(120,120,120):kBlackCColor);d->drawLine(CPoint(a.x+std::cos(angle)*(a.r*.55),a.y+std::sin(angle)*(a.r*.55)),CPoint(a.x+std::cos(angle)*(a.r-8),a.y+std::sin(angle)*(a.r-8)));
 if(!(a.id==1&&c->getParamNormalized(0)<.5))text(d,value(a.id),CRect(a.x-100,a.y+a.r+1,a.x+100,a.y+a.r+34),24,disabled(a.id)?CColor(120,120,120):kBlackCColor);
 }
 if(page==0&&c->getParamNormalized(0)<.5){for(int i=0;i<2;++i){double x=i?336:96;d->setFillColor(kWhiteCColor);d->setFrameColor(kBlackCColor);d->setLineWidth(3);d->drawRect(CRect(x-42,246+top-42,x+42,246+top+42),kDrawFilledAndStroked);text(d,i?">":"<",CRect(x-42,246+top-42,x+42,246+top+42),56);}d->setFillColor(CColor(210,210,210));d->drawRect(CRect(26,324+top,406,364+top),kDrawFilled);text(d,value(1),CRect(26,324+top,406,364+top),25);}
 setDirty(false);}
 std::string programName(){return matchedProgram>=0?programNames[matchedProgram]:"Custom";}
 CMouseEventResult onMouseDown(CPoint&p,const CButtonState&button)override{if(!button.isLeftButton())return kMouseEventNotHandled;finish();if(p.y<64){if(p.x<760){page=std::clamp(int(p.x/190),0,3);refresh();}else if(p.x<838||p.x>=1220){program=(program+(p.x<838?14:1))%15;c->preset(program);}invalid();return kMouseDownEventHandledButDontNeedMovedOrUpEvents;}
 if(page==0&&c->getParamNormalized(0)<.5&&std::abs(p.y-(246+top))<44&&(std::abs(p.x-96)<44||std::abs(p.x-336)<44)){c->beginEdit(1);change(1,c->getParamNormalized(1)+(p.x<216?-1:1)/12.);c->endEdit(1);return kMouseDownEventHandledButDontNeedMovedOrUpEvents;}
 for(auto&a:cells){double w=a.w?a.w/2:a.r+15;if(std::abs(p.x-a.x)>w||std::abs(p.y-a.y)>a.r+16||disabled(a.id))continue;if(a.image){c->beginEdit(a.id);change(a.id,c->getParamNormalized(a.id)>=.5?0:1);c->endEdit(a.id);return kMouseDownEventHandledButDontNeedMovedOrUpEvents;}editing=a.id;startY=p.y;startV=c->getParamNormalized(editing);c->beginEdit(editing);if(editing==16)change(16,(p.x-129)/542);return kMouseEventHandled;}return kMouseEventNotHandled;}
 CMouseEventResult onMouseMoved(CPoint&p,const CButtonState&)override{if(editing<0)return kMouseEventNotHandled;change(editing,editing==16?(p.x-129)/542:startV+(startY-p.y)/240);return kMouseEventHandled;}
 CMouseEventResult onMouseUp(CPoint&,const CButtonState&)override{finish();return kMouseEventHandled;}
 CMouseEventResult onMouseCancel()override{finish();return kMouseEventHandled;}
};
CView*Controller::createCustomView(UTF8StringPtr n,const UIAttributes&,const IUIDescription*,VST3Editor*){return !std::strcmp(n,"ClifTapePanel")?new Panel(this):nullptr;}
#ifndef CLIF_SMOKE
IPlugView*PLUGIN_API Controller::createView(FIDString n){if(std::strcmp(n,ViewType::kEditor))return nullptr;auto*e=new VST3Editor(this,"Main","cliftape.uidesc");e->setDelegate(this);return e;}
#else
IPlugView*PLUGIN_API Controller::createView(FIDString){return nullptr;}
#endif
}
