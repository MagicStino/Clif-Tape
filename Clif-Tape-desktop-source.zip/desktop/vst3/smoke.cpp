#include "vstgui4/vstgui/lib/vstguiinit.h"
#include "editor.cpp"
#include "vstgui4/vstgui/lib/coffscreencontext.h"
#include "vstgui4/vstgui/lib/platform/platformfactory.h"
#include "vstgui4/vstgui/lib/platform/linux/linuxfactory.h"
#include "vstgui4/vstgui/uidescription/uiattributes.h"
#include <fstream>
#include <iostream>
#include <stdexcept>
using namespace ClifTape;
void require(bool v,const char*s){if(!v)throw std::runtime_error(s);}
int main(int argc,char**argv){
 VSTGUI::init(nullptr);VSTGUI::getPlatformFactory().asLinuxFactory()->setResourcePath(std::string(argv[1])+"/");
 {
 Controller c;require(c.initialize(nullptr)==kResultOk,"controller init");Panel p(&c);p.onIdle();
 auto click=[&](double x,double y){VSTGUI::CPoint at(x,y);p.onMouseDown(at,VSTGUI::CButtonState(VSTGUI::kLButton));p.onIdle();};
 auto render=[&](const char*name){auto dc=VSTGUI::COffscreenContext::create({1280,692});require(bool(dc),"offscreen context");dc->beginDraw();p.draw(dc);dc->endDraw();auto png=VSTGUI::getPlatformFactory().createBitmapMemoryPNGRepresentation(dc->getBitmap()->getPlatformBitmap());std::ofstream out(std::string(argv[2])+"/"+name,std::ios::binary);out.write((const char*)png.data(),png.size());require(png.size()>10000,"artwork rendered");};
 render("desktop-tone.png");click(1055,117);require(c.getParamNormalized(0)==1,"digital toggle");render("desktop-digital.png");click(300,30);render("desktop-motion.png");click(490,30);render("desktop-noise.png");click(670,30);click(300,386);require(c.getParamNormalized(13)==0,"gate off persists");render("desktop-gate-off.png");click(650,384);require(c.getParamNormalized(14)==float(1.f/9),"disabled fade unchanged");click(300,386);require(c.getParamNormalized(13)==1,"gate on");render("desktop-gate.png");c.terminate();
 }
 {Processor p;require(p.initialize(nullptr)==kResultOk,"processor init");ProcessSetup setup{};setup.sampleRate=48000;setup.maxSamplesPerBlock=256;setup.symbolicSampleSize=kSample32;require(p.setupProcessing(setup)==kResultOk,"setup");p.setActive(true);p.setProcessing(true);float l[256]{},r[256]{},ol[256]{},orr[256]{};float*in[]={l,r},*out[]={ol,orr};AudioBusBuffers ib{},ob{};ib.numChannels=ob.numChannels=2;ib.channelBuffers32=in;ob.channelBuffers32=out;ProcessData d{};d.symbolicSampleSize=kSample32;d.numInputs=d.numOutputs=1;d.inputs=&ib;d.outputs=&ob;d.numSamples=256;double difference=0;for(int b=0;b<20;++b){for(int i=0;i<256;++i)l[i]=r[i]=.2f*std::sin((b*256+i)*.07);require(p.process(d)==kResultOk,"process");for(int i=0;i<256;++i){require(std::isfinite(ol[i]),"finite audio");difference+=std::abs(ol[i]-l[i]);}}require(difference>1,"DSP active, not dry passthrough");p.setProcessing(false);p.setActive(false);p.terminate();}
 VSTGUI::exit();std::cout<<"UI controls, six renders and active DSP passed\n";
}
