#include "plugin.h"
#include "public.sdk/source/main/pluginfactory.h"
using namespace Steinberg::Vst;
BEGIN_FACTORY_DEF("MagicStino","https://github.com/MagicStino/Clif-Tape","")
DEF_CLASS2(INLINE_UID_FROM_FUID(ClifTape::ProcessorID),PClassInfo::kManyInstances,kVstAudioEffectClass,"Clif Tape",Vst::kDistributable,"Fx|Distortion|Modulation","0.2.0",kVstVersionString,ClifTape::Processor::createInstance)
DEF_CLASS2(INLINE_UID_FROM_FUID(ClifTape::ControllerID),PClassInfo::kManyInstances,kVstComponentControllerClass,"Clif Tape Controller",0,"","0.2.0",kVstVersionString,ClifTape::Controller::createInstance)
END_FACTORY
