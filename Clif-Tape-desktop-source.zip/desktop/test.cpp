#include "../src/vst2.hpp"
#include <cassert>
#include <cmath>
#include <vector>
#include <cstdio>
#ifdef _WIN32
#include <windows.h>
#else
#include <dlfcn.h>
#endif
intptr_t host(AEffect*e,int32_t op,int32_t i,intptr_t,void*,float v){if(op==0){assert(i>=0&&i<18);e->setParameter(e,i,v);}return 2400;}
int main(int argc,char**argv){assert(argc==2);
#ifdef _WIN32
 auto lib=LoadLibraryA(argv[1]);assert(lib);auto main=(AEffect*(*)(audioMasterCallback))GetProcAddress(lib,"VSTPluginMain");
#else
 auto lib=dlopen(argv[1],RTLD_NOW);if(!lib){puts(dlerror());return 1;}auto main=(AEffect*(*)(audioMasterCallback))dlsym(lib,"VSTPluginMain");
#endif
 assert(main);auto*e=main(host);assert(e&&e->numParams==18&&e->numPrograms==15);e->dispatcher(e,0,0,0,nullptr,0);e->dispatcher(e,10,0,0,nullptr,48000);float l[512]{},r[512]{},a[512]{},b[512]{};float*in[]={l,r},*out[]={a,b};for(int i=0;i<512;++i)l[i]=r[i]=.1f*std::sin(i*.05f);
 for(int p=0;p<15;++p){assert(e->dispatcher(e,2,0,p,nullptr,0));for(int i=0;i<18;++i){char label[8]{};e->dispatcher(e,8,i,0,label,0);assert(label[0]);assert(e->dispatcher(e,26,i,0,nullptr,0));}e->processReplacing(e,in,out,512);for(float x:a)assert(std::isfinite(x));}
 e->setParameter(e,0,1);e->setParameter(e,2,.75f);e->setParameter(e,9,1);e->setParameter(e,11,0);e->setParameter(e,13,0);e->processReplacing(e,in,out,512);assert(e->getParameter(e,13)==0);assert(e->getParameter(e,9)==1);assert(e->getParameter(e,11)==0);void*data;auto n=e->dispatcher(e,23,0,0,&data,0);std::vector<char> state((char*)data,(char*)data+n);e->setParameter(e,2,0);assert(e->dispatcher(e,24,0,n,state.data(),0));assert(e->getParameter(e,2)==.75f);e->dispatcher(e,1,0,0,nullptr,0);puts("PASS: desktop host load, all controls, 15 presets, automation echo, gate toggle, saved state and finite audio");}
