from pathlib import Path
import sys,zipfile,hashlib,subprocess
platform=sys.argv[1]
root=Path(__file__).resolve().parent
bundle=root/'vst3/build/VST3/Release/ClifTape.vst3'
assert bundle.is_dir(),str(bundle)
if platform=='macOS': subprocess.run(['codesign','--force','--deep','--sign','-',str(bundle)],check=True)
out=root.parent/'dist';out.mkdir(exist_ok=True)
archive=out/f'Clif-Tape-0.2.0-{platform}-VST3.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(bundle.rglob('*')):
  if p.is_file(): z.write(p,p.relative_to(bundle.parent))
 for name in ['STEINBERG-LICENSE.txt','VSTGUI-LICENSE.txt']: z.write(root/'vst3'/name,name)
 z.write(root/'INSTALL.txt','INSTALL.txt')
print(archive,hashlib.sha256(archive.read_bytes()).hexdigest())
