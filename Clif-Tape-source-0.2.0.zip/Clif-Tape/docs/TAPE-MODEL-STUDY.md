# Tape-model and DEGRADE study — 29 October 2026

## What was measured

The local reference engine was run at its native 32 kHz in the existing ARM harness. The model selector used the verified 13 discrete positions. Wow, Flutter, Failure, noise, crackle and spread were off. Raw audio and disassembly remain outside the Clean project. No reference coefficient arrays or routines were copied into the new engine.

First pass: 32 coherent sine frequencies from 40 Hz to 12 kHz. New cascaded parametric filters were optimized against measured magnitude responses relative to the reference's Off model. Independent validation: 63 additional frequencies from 45 Hz to 11.5 kHz, using actual Clean DSP output at 48 kHz. Error statistics floor responses at −60 dB; they do not describe phase or response below that floor. Off is deliberately unity rather than reproducing the reference's overall gain and slight converter-bandwidth loss.

## Model results

| Position | New label | Measured character | RMS error (dB) | Largest error (dB) |
|---|---|---|---:|---:|
| 0 | Off | Unfiltered reference | 0.00 | 0.00 |
| 1 | Video 1 | Broad low-mid rise, steep treble roll-off | 0.27 | 0.83 |
| 2 | Video 2 | Stronger bass/low mids, lower treble cutoff | 0.40 | 0.93 |
| 3 | Video 3 | Very narrow bass-heavy bandwidth | 0.00 | 0.00 |
| 4 | Reel | Low-bass trim, low-mid bump, broad top end | 0.18 | 0.49 |
| 5 | Tape | Resonant low mids with dark upper range | 0.24 | 0.90 |
| 6 | Camera | Upper-mid emphasis | 0.17 | 0.63 |
| 7 | Voice 1 | Strong bass removal, presence emphasis | 0.06 | 0.14 |
| 8 | Voice 2 | Stronger bass removal, resonant upper mids | 0.07 | 0.20 |
| 9 | Pocket | Mid emphasis with a narrow upper-mid notch | 0.38 | 1.57 |
| 10 | Walk | Broad, modest presence lift | 0.09 | 0.20 |
| 11 | Bright | Strong treble lift with recessed mids | 0.20 | 0.60 |
| 12 | Studio | Broad mid lift with gentler treble loss | 0.34 | 0.91 |

## Saturation interaction

At 997 Hz and input amplitudes 0.005, 0.05 and 0.25, saturation-off model gain was unchanged with level; measured harmonics were below the report's 0.01% display resolution. At half saturation, the level-dependent fundamental gain change was essentially the same across models while harmonic content varied strongly with the model. For example, at the highest test level the unfiltered position measured about 19.9% THD, while the dark Video 3 position measured about 0.25% and Voice 1 about 113.6% (harmonics exceeding its attenuated fundamental). This supports saturation before model filtering. The new engine now uses that order. Its saturation transfer function remains an independently designed approximation, not a fitted match.

## DEGRADE

Tested at 0, 25, 50, 75 and 100%, with low-pass fully open and high-pass at its minimum in the reference. Increasing DEGRADE strongly reduces high-frequency response. At 997 Hz, the 100% reference setting attenuated the fundamental by roughly 58 dB relative to 0%. Across a 50:1 input-level range the response scaled proportionally, unlike deep bit-depth quantization. Impulse response also varied with sampling phase. This supports a bandwidth/sample-update mechanism; it does not establish its exact internal algorithm.

Clean's replacement therefore combines reduced sample-update rate with pre/post low-pass filtering and removes the aggressive quantizer. This is a behavioral approximation; unlike the Tape magnitude curves, it has not been fitted to a stated curve-error tolerance.

## Requested control changes

- Clean Start: Noise Level 10%, Noise Sound off. Existing user states and individual other factory noise levels remain unchanged.
- Dark noise blends into white from 7% through 30%; prior one-third maximum gain retained.
- Crackle event density relative to the old 50% setting: 35% → 0.5×, 50% → 1×, 100% → 1.5×. Below 35% gain fades in at minimum density. Above 50% event gain is fixed. Failure still scales base event density.
- Model switches crossfade over 25 ms. Parameter IDs, MIDI routing, native state format and Q-Link mappings retained.

## Limits and validation

Native host audio checks, preset/state/UI-echo checks, measured-curve regression, specified crackle mapping and low-level DEGRADE linearity pass. Measured magnitude matching is not phase matching, analog-front-end matching, a full saturation match or listening approval. No physical reference pedal was available. Version 0.1.2 is a new test build; the installed Force version remains 0.1.1 until an explicit deployment.
