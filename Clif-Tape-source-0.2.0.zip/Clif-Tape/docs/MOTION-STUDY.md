# Wow and Flutter tuning — 0.1.3

Reference: native 32 kHz engine, Tape mode, model Off, saturation/failure/noise/crackle/spread off, 997 Hz sine. New engine rendered at 48 kHz. Pitch estimated from interpolated positive zero crossings over seconds 2–19 of each 20-second render. Knob midpoint is 128/255. These are finite measurements, not an exact match to the reference modulation trajectory.

| Control | Knob | Reference RMS pitch (cents) | New RMS pitch (cents) |
|---|---:|---:|---:|
| Wow | 50% | 32.0 | 32.9 |
| Wow | 100% | 68.2 | 79.5 |
| Flutter | 50% | 18.3 | 18.8 |
| Flutter | 100% | 36.7 | 44.9 |

The reference Wow trajectory is irregular; the new independent synthesis uses slowly randomized speed and a mildly asymmetric waveform. Flutter combines approximately 40.7 Hz with a smaller 16 Hz component, replacing 7.3 Hz. The control response is unchanged up to 50% of the new base depth; above 50% a smooth extra depth factor reaches 1.2 at maximum. This does not preserve the old 0.1.2 sound at lower settings: the base motion was deliberately retuned toward the reference.

The motion generator owns its phases and random sequence, so the mechanical sound phases and noise random sequence are unaffected. At both controls full and any Spread offset the designed delay excursion is bounded by 6.78 ms, inside the 8 ms base delay. Mix, latency, parameter IDs, MIDI, state and Q-Link mappings remain unchanged.

Validation: host audio/control tests, preset/state/UI echo, Tape curve regression and motion tests pass. Motion tests cover 8/44.1/48/96/192 kHz, continuity after initialization, finite bounds, exact zero settings, deterministic reset, pitch-depth range and upper-half response. ARM runtime checks use QEMU; device listening remains pending. Force currently has 0.1.2; this 0.1.3 build is not installed.
