<?xml version="1.0" encoding="UTF-8"?>

<pluginstate>
  <version file="1" date="2026-10-28-00-00"/>
  <PLUGIN name="Clif Tape" descriptiveName="Clif Tape" format="VST" category="Effect" manufacturer="MagicStino"
          version="1.0" file="%payload-path%/MagicStino - VST - Clif Tape/clif_tape.so" uid="436c4c43" isInstrument="0" fileTime="0"
          infoUpdateTime="0" numInputs="2" numOutputs="2" isShell="0"/>
  <preset>Warm VHS</preset>
  <state>272.CMlaKA....fQBMDZ....ALDaLMD....x....A...............................................................................................................................................................................vQ0PLMz.....R....H.....6QgiO....+rppp5SyLybOyLyr97nv0ySyLyrO.........................................7C...vO...f9....7yUgIWafXERSA.....................</state>
</pluginstate>
