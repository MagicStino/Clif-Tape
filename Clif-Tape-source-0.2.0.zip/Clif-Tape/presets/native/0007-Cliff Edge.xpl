<?xml version="1.0" encoding="UTF-8"?>

<pluginstate>
  <version file="1" date="2026-10-28-00-00"/>
  <PLUGIN name="Clif Tape" descriptiveName="Clif Tape" format="VST" category="Effect" manufacturer="MagicStino"
          version="1.0" file="%payload-path%/MagicStino - VST - Clif Tape/clif_tape.so" uid="436c4c43" isInstrument="0" fileTime="0"
          infoUpdateTime="0" numInputs="2" numOutputs="2" isShell="0"/>
  <preset>Cliff Edge</preset>
  <state>272.CMlaKA....fQBMDZ....ALDaLMD....x....A...............................................................................................................................................................................vQ0PLMz.....R....b....P35QwO....+....8SOJbsOlYl49XlYl7SyLyrO....+................................nYlY3C...vOyLyr9....7yPrklYlARQjcVY...................</state>
</pluginstate>
