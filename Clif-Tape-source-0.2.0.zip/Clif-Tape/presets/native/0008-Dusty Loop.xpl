<?xml version="1.0" encoding="UTF-8"?>

<pluginstate>
  <version file="1" date="2026-10-28-00-00"/>
  <PLUGIN name="Clif Tape" descriptiveName="Clif Tape" format="VST" category="Effect" manufacturer="MagicStino"
          version="1.0" file="%payload-path%/MagicStino - VST - Clif Tape/clif_tape.so" uid="436c4c43" isInstrument="0" fileTime="0"
          infoUpdateTime="0" numInputs="2" numOutputs="2" isShell="0"/>
  <preset>Dusty Loop</preset>
  <state>272.CMlaKA....fQBMDZ....ALDaLMD....x....A...............................................................................................................................................................................vQ0PLMz.....R....f....viBWeO1iB29....7C6QgaOJb8n9nv0i1SyLyrO....+................................nYlY5C...vO....9....7CQ0MGc4ABSu8Fb...................</state>
</pluginstate>
