// Original parametric filter designs fitted to measured reference responses.
// Optimized tone-profile design parameters.
#pragma once
#include <array>
#include <cmath>
#include <algorithm>
namespace clif {
struct FilterDesign {int type;double hz,q,db;}; // 0 bypass, 1 LP, 2 HP, 3 bell
struct ToneDesign {double gain;std::array<FilterDesign,5> sections;};
inline constexpr ToneDesign toneDesigns[13]={
{1,{{{0,1000,.707,0},{0,1000,.707,0},{0,1000,.707,0},{0,1000,.707,0},{0,1000,.707,0}}}},
{1.01693338,{{{1,19952.6231,0.496187695,0},{1,1270.45557,0.459093206,0},{3,2273.80867,0.503175443,10.2882179},{0,1000,.707,0},{0,1000,.707,0}}}},
{1.41107879,{{{1,832.697479,0.517774929,0},{1,19952.6231,0.329462877,0},{3,1407.86206,0.410286541,7.00393745},{0,1000,.707,0},{0,1000,.707,0}}}},
{1.87426176,{{{1,283.799647,0.938381755,0},{1,879.54629,0.908581733,0},{3,10025.1712,1.03977188,11.70582},{0,1000,.707,0},{0,1000,.707,0}}}},
{0.590179798,{{{2,19.9526231,0.501453935,0},{1,9286.04545,0.429768892,0},{3,213.343733,0.729845066,6.14407637},{3,643.615985,0.30892356,-0.836840067},{0,1000,.707,0}}}},
{1.20128154,{{{1,867.301516,0.906920808,0},{1,19952.6231,0.26175076,0},{3,19952.6231,0.322472776,4.52346709},{0,1000,.707,0},{0,1000,.707,0}}}},
{0.762932458,{{{1,18907.0355,0.25,0},{3,4059.60754,1.07619158,3.91345383},{3,2124.31349,0.895977898,6.46298939},{0,1000,.707,0},{0,1000,.707,0}}}},
{3.68365379,{{{2,19.9526231,0.707870642,0},{2,2697.45487,0.953493188,0},{1,7829.74331,0.537904974,0},{3,8540.92841,0.708671405,-5.96685553},{0,1000,.707,0}}}},
{0.744966835,{{{2,1415.25308,0.923099166,0},{2,130.711382,0.250977038,0},{2,36.6447132,0.785308945,0},{1,19952.6231,0.300407047,0},{3,2151.61068,0.483323509,12.4195243}}}},
{2.98300551,{{{2,251.391117,0.298465274,0},{1,3911.76487,0.25,0},{3,192.521807,0.276241795,-9.63826326},{3,2348.43497,4.2557116,-30.3633093},{0,1000,.707,0}}}},
{0.984270524,{{{1,14264.0453,0.422744224,0},{3,2395.84881,0.529985313,2.13004781},{0,1000,.707,0},{0,1000,.707,0},{0,1000,.707,0}}}},
{0.446265929,{{{3,8095.90127,0.25,15.3410701},{3,1303.12247,0.638629852,-2.98020854},{3,1986.44709,1.29487423,-8.20408158},{0,1000,.707,0},{0,1000,.707,0}}}},
{0.962343952,{{{1,19928.4641,0.25,0},{3,1336.04439,0.809024916,4.03910689},{3,6610.8455,0.612244941,-3.27901965},{0,1000,.707,0},{0,1000,.707,0}}}},
};
struct BiquadCoefficients {double b0=1,b1=0,b2=0,a1=0,a2=0;};
struct BiquadState {double z1=0,z2=0;float tick(float x,const BiquadCoefficients& c){double y=c.b0*x+z1;z1=c.b1*x-c.a1*y+z2;z2=c.b2*x-c.a2*y;return float(y);}};
inline BiquadCoefficients designFilter(FilterDesign f,double sr){
 if(!f.type)return {};
 double w=6.283185307179586*std::clamp(f.hz,10.,sr*.45)/sr,c=std::cos(w),a=std::sin(w)/(2*f.q),A=std::pow(10.,f.db/40),a0=1+a;
 BiquadCoefficients b;
 if(f.type==1){b.b0=(1-c)/2;b.b1=1-c;b.b2=b.b0;b.a1=-2*c;b.a2=1-a;}
 else if(f.type==2){b.b0=(1+c)/2;b.b1=-1-c;b.b2=b.b0;b.a1=-2*c;b.a2=1-a;}
 else {b.b0=1+a*A;b.b1=-2*c;b.b2=1-a*A;a0=1+a/A;b.a1=-2*c;b.a2=1-a/A;}
 b.b0/=a0;b.b1/=a0;b.b2/=a0;b.a1/=a0;b.a2/=a0;return b;
}
class ToneModels {
 std::array<std::array<BiquadCoefficients,5>,13> coefficients;
 std::array<BiquadState,5> state{},oldState{};int selected=0,previous=0;float fade=1,fadeStep=.001;
 float run(float x,int model,std::array<BiquadState,5>& memory){for(int i=0;i<5;++i)x=memory[i].tick(x,coefficients[model][i]);return x*float(toneDesigns[model].gain);}
 public:
 void prepare(double sr){for(int m=0;m<13;++m)for(int i=0;i<5;++i)coefficients[m][i]=designFilter(toneDesigns[m].sections[i],sr);state={};oldState={};selected=previous=0;fade=1;fadeStep=float(1/(.025*sr));}
 float tick(float x,int model){if(model!=selected){previous=selected;oldState=state;selected=model;state={};fade=0;}float y=run(x,selected,state);if(fade<1){float old=run(x,previous,oldState);y=old*(1-fade)+y*fade;fade=std::min(1.f,fade+fadeStep);}return y;}
};
}
