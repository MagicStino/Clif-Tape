#include "vst2.hpp"
#include "dsp.hpp"
#include "parameters.hpp"
#include "presets.hpp"

#include <atomic>
#include <memory>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <new>
namespace {
constexpr int MODEL_SELECT=18,MODEL_PREV=19,MODEL_NEXT=20,DRIVE=21,NOISE_SOUND=22,MECH_SOUND=23,SILENCE_GATE=24,FADE_IN=25,FADE_OUT=26,HOST_PARAMS=27;
const char* modelShort[]={"Off","Video 1","Video 2","Video 3","Reel","Tape","Camera","Voice 1","Voice 2","Pocket","Walk","Bright","Studio"};
int modelIndex(float v){return std::clamp(int(std::lround(v*12)),0,12);}
constexpr uint32_t ID=0x436c4c43;
struct Chunk {uint32_t magic=0x434c4354,version=3,count=PARAMS,program=0;float values[PARAMS];char name[24]{};float noiseEnabled=-1.f;float gate[3]{1,1.f/9,8.f/15};};
constexpr size_t LEGACY_CHUNK_SIZE=offsetof(Chunk,noiseEnabled);
constexpr size_t V4_CHUNK_SIZE=offsetof(Chunk,gate);
float clean(float x){return std::isfinite(x)?std::clamp(x,-1.f,1.f):0.f;}
int32_t pcm(float x){return int32_t(std::clamp(double(clean(x))*2147483648.,-2147483648.,2147483647.));}
struct Plugin {
 AEffect fx{};audioMasterCallback host;std::atomic<float> params[PARAMS];clif::DSP engine;
 double rate=0;int latency=0;
 std::atomic<float> gate[3]{{1.f},{1.f/9},{8.f/15}};
 std::atomic<float> noiseEnabled{-1.f};
 bool noiseOn()const{float enabled=noiseEnabled.load();return enabled<0?option(params[P_noise].load(),3)>0:enabled>=.5f;}
 bool mechOn()const{return option(params[P_noise].load(),3)>0&&params[P_hum].load()<.5f;}
 Chunk chunk{};int currentProgram=0;char program[24]="Clean Start";std::atomic<bool> hostBypass{false};std::atomic<bool> presetDisplayPending{false};std::atomic<bool> modeDisplayPending{false};std::atomic<bool> modelDisplayPending{false};std::atomic<float> modelDial{0};std::atomic<bool> driveDisplayPending{false};bool ready=false;float mixCurrent=.4f;
 Plugin(audioMasterCallback h):host(h){for(int i=0;i<PARAMS;++i)params[i].store(presetValues[0][i]);configure(44100);}
 void configure(double sr){if(!std::isfinite(sr)||sr<8000||sr>192000||sr==rate)return;rate=sr;engine.prepare(sr);latency=engine.latency();fx.initialDelay=latency;}
 void activate(){ready=true;}
 void snapshot(float* v){for(int i=0;i<PARAMS;++i)v[i]=params[i].load(std::memory_order_relaxed);}
 static int option(float v,int count){return std::clamp(int(std::lround(v*(count-1))),0,count-1);}
 // MPC caches displayed controls separately from DSP values. Notify once after a
 // complete preset load, outside its setChunk/setProgram call. Host writes never
 // request this refresh: MPC can echo notifications back through setParameter.
 void refreshPresetDisplay(){
  if(!host)return;
  bool preset=presetDisplayPending.exchange(false,std::memory_order_acquire);
  bool mode=modeDisplayPending.exchange(false,std::memory_order_acquire);
  bool model=modelDisplayPending.exchange(false,std::memory_order_acquire);
  bool drive=driveDisplayPending.exchange(false,std::memory_order_acquire);
  if(!preset&&!mode&&!model&&!drive)return;
  if(preset)for(int k=0;k<PARAMS;++k)if(k!=P_drop&&k!=P_snag&&k!=P_gain)host(&fx,0,k,0,nullptr,params[k].load(std::memory_order_relaxed));
  if(model&&!preset)host(&fx,0,P_model,0,nullptr,params[P_model].load());
  if(preset||model||mode){int k=modelIndex(params[P_model].load());float dial=params[P_classic].load()>=.5f?params[P_model].load():k/12.f;modelDial.store(dial);host(&fx,0,MODEL_SELECT,0,nullptr,dial);host(&fx,0,MODEL_PREV,0,nullptr,0);host(&fx,0,MODEL_NEXT,0,nullptr,0);}
  if(drive&&!preset)host(&fx,0,P_saturate,0,nullptr,params[P_saturate].load());
  if(preset||mode||drive){float raw=params[P_saturate].load();host(&fx,0,DRIVE,0,nullptr,raw);}
  if(preset){host(&fx,0,NOISE_SOUND,0,nullptr,noiseOn()?1.f:0.f);host(&fx,0,MECH_SOUND,0,nullptr,mechOn()?1.f:0.f);}
  if(preset)for(int k=0;k<3;++k)host(&fx,0,SILENCE_GATE+k,0,nullptr,gate[k].load());
  host(&fx,42,0,0,nullptr,0); // audioMasterUpdateDisplay: labels and program name
 }
 void process(float** ins,float** outs,int n){if(n<=0||!outs)return;refreshPresetDisplay();float v[PARAMS];snapshot(v);bool bypass=hostBypass.load();
  if(!ready){for(int i=0;i<n;++i){float l=ins&&ins[0]?clean(ins[0][i]):0,r=ins&&ins[1]?clean(ins[1][i]):l;if(outs[0])outs[0][i]=l;if(outs[1])outs[1][i]=r;}return;}

  clif::Controls c;c.silenceGate=gate[0].load();c.fadeIn=1+gate[1].load()*9;c.fadeOut=gate[2].load()*15;c.wow=v[P_wow];c.flutter=v[P_flutter];c.drive=v[P_saturate];c.degrade=v[P_saturate];c.failure=v[P_failure];c.mix=v[P_mix];c.volume=v[P_volume];c.digital=v[P_classic];c.lowpass=v[P_model];c.highpass=v[P_failure];c.spread=v[P_spread];c.mono=v[P_miso];c.hiss=noiseOn()?v[P_hiss]:0;c.mechanical=mechOn()?(v[P_mechanical]*2-1):0;c.crackle=v[P_crinkle];c.model=modelIndex(v[P_model]);
  for(int i=0;i<n;++i){clif::Stereo x{ins&&ins[0]?clean(ins[0][i]):0,ins&&ins[1]?clean(ins[1][i]):0};auto y=engine.tick(x,c,bypass);if(outs[0])outs[0][i]=y.l;if(outs[1])outs[1][i]=y.r;}
 }

};
Plugin* get(AEffect*e){return static_cast<Plugin*>(e->object);}
void put(char*dst,const char*s,size_t n){if(dst&&s&&n){std::strncpy(dst,s,n-1);dst[n-1]=0;}}
void set(AEffect*e,int32_t i,float v){
 if(!std::isfinite(v))return;auto*p=get(e);v=std::clamp(v,0.f,1.f);
 if(i>=SILENCE_GATE&&i<=FADE_OUT){if(i!=SILENCE_GATE&&p->gate[0].load()<.5f)return;p->gate[i-SILENCE_GATE].store(v);return;}
 if(i==NOISE_SOUND||i==MECH_SOUND){
  bool on=v>=.5f;if(on==(i==NOISE_SOUND?p->noiseOn():p->mechOn()))return;
  if(i==NOISE_SOUND){
   p->noiseEnabled.store(on?1.f:0.f);
   if(on&&Plugin::option(p->params[P_noise].load(),3)==0){p->params[P_hum].store(1.f);p->params[P_noise].store(1.f);}
  }else{
   if(on&&Plugin::option(p->params[P_noise].load(),3)==0){p->noiseEnabled.store(0.f);p->params[P_noise].store(1.f);}
   p->params[P_hum].store(on?0.f:1.f);
  }
  p->presetDisplayPending.store(true,std::memory_order_release);return;
 }
 if(i==DRIVE){float raw=p->params[P_saturate].load();if(v==raw)return;p->params[P_saturate].store(v);p->driveDisplayPending.store(true,std::memory_order_release);return;}
 if(i==MODEL_SELECT&&p->params[P_classic].load()>=.5f){p->params[P_model].store(v);p->modelDial.store(v);return;}
 if(i==MODEL_SELECT||i==MODEL_PREV||i==MODEL_NEXT){
  int current=modelIndex(p->params[P_model].load());int next=current;
  if(i==MODEL_SELECT){p->modelDial.store(v);next=std::clamp(int(std::lround(v*12)),0,12);}
  else if(v>.5f){next=std::clamp(current+(i==MODEL_NEXT?1:-1),0,12);p->modelDisplayPending.store(true,std::memory_order_release);}
  if(next!=current){p->params[P_model].store(next/12.f);p->modelDisplayPending.store(true,std::memory_order_release);}return;
 }
 if(i>=0&&i<PARAMS){float old=p->params[i].exchange(v,std::memory_order_relaxed);if(i==P_classic&&((old<.5f)!=(v<.5f)))p->modeDisplayPending.store(true,std::memory_order_release);if(i==P_saturate&&old!=v)p->driveDisplayPending.store(true,std::memory_order_release);if(i==P_hum&&old!=v)p->presetDisplayPending.store(true,std::memory_order_release);if(i==P_noise&&old!=v)p->presetDisplayPending.store(true,std::memory_order_release);if(i==P_model&&old!=v)p->modelDisplayPending.store(true,std::memory_order_release);}
}
float value(AEffect*e,int32_t i){auto*p=get(e);if(i>=SILENCE_GATE&&i<=FADE_OUT)return p->gate[i-SILENCE_GATE].load();if(i==NOISE_SOUND)return p->noiseOn()?1.f:0.f;if(i==MECH_SOUND)return p->mechOn()?1.f:0.f;if(i==DRIVE){float raw=p->params[P_saturate].load();return raw;}if(i==MODEL_SELECT)return p->params[P_classic].load()>=.5f?p->params[P_model].load():modelIndex(p->params[P_model].load())/12.f;if(i==MODEL_PREV||i==MODEL_NEXT)return 0;return i>=0&&i<PARAMS?p->params[i].load(std::memory_order_relaxed):0;}
void process(AEffect*e,float**in,float**out,int32_t n){get(e)->process(in,out,n);}
const char* opts(int i,int k){static const char* noise[]={"None","Mild","Heavy"},*gain[]={"Line","Inst","High"};if(i==P_classic)return k?"Digital":"Tape";if(i==P_noise)return noise[k];if(i==P_gain)return gain[k];if(i==P_hum)return k?"Off":"On";return k?"On":"Off";}
intptr_t dispatch(AEffect*e,int32_t op,int32_t i,intptr_t val,void*ptr,float opt){auto*p=get(e);switch(op){
 case 0:try{p->activate();return 1;}catch(...){return 0;}
 case 1:delete p;return 1;
 case 2:if(val>=0&&val<PROGRAMS){p->gate[0].store(1);p->gate[1].store(1.f/9);p->gate[2].store(8.f/15);p->noiseEnabled.store(-1.f);p->currentProgram=val;put(p->program,presetNames[val],24);for(int k=0;k<PARAMS;++k)set(e,k,presetValues[val][k]);p->presetDisplayPending.store(true,std::memory_order_release);return 1;}return 0;
 case 3:return p->currentProgram;
 case 4:put(p->program,(const char*)ptr,sizeof(p->program));return 0;
 case 5:put((char*)ptr,p->program,24);return 1;
 case 6:put((char*)ptr,"",8);return 0;
 case 7:if(i>=SILENCE_GATE&&i<=FADE_OUT){char s[8];if(i==SILENCE_GATE)put(s,value(e,i)>=.5f?"On":"Off",8);else std::snprintf(s,8,"%.1f s",i==FADE_IN?1+value(e,i)*9:value(e,i)*15);put((char*)ptr,s,8);return 1;}if(i==NOISE_SOUND||i==MECH_SOUND){put((char*)ptr,value(e,i)>=.5f?"On":"Off",8);return 1;}if(i==DRIVE){char s[8];std::snprintf(s,sizeof(s),"%.1f",value(e,i)*100);put((char*)ptr,s,8);return 1;}if(i==MODEL_SELECT){if(p->params[P_classic].load()<.5f)put((char*)ptr,modelShort[modelIndex(p->params[P_model].load())],8);else{char s[8];std::snprintf(s,sizeof(s),"%.1f",p->params[P_model].load()*100);put((char*)ptr,s,8);}return 1;}if(i>=0&&i<PARAMS){char s[16];float v=value(e,i);if(steps[i])put(s,opts(i,Plugin::option(v,steps[i])),sizeof(s));else if(i==P_mechanical){if(std::abs(v-.5f)<1.f/255)put(s,"Silent",sizeof(s));else std::snprintf(s,sizeof(s),"%s %.0f",v<.5f?"VCR":"Hum",std::abs(v-.5f)*200);}else if(i==P_mix)std::snprintf(s,sizeof(s),"%.0f%%",v*100);else std::snprintf(s,sizeof(s),"%.1f",v*100);put((char*)ptr,s,8);}return 0;
 case 8:if(i>=SILENCE_GATE&&i<=FADE_OUT){put((char*)ptr,i==SILENCE_GATE?"SilGate":i==FADE_IN?"Fade In":"FadeOut",8);return 1;}if(i==NOISE_SOUND||i==MECH_SOUND){put((char*)ptr,i==NOISE_SOUND?"Noise":"Mech",8);return 1;}if(i==DRIVE){put((char*)ptr,value(e,P_classic)>=.5f?"DEGRADE":"Saturate",8);return 1;}if(i>=MODEL_SELECT&&i<HOST_PARAMS){put((char*)ptr,i==MODEL_SELECT?(value(e,P_classic)>=.5f?"LPF":"Model"):i==MODEL_PREV?"Prev":"Next",8);return 1;}if(i>=0&&i<PARAMS){const char* name=i==P_hum?"Mech":i==P_hiss?"NoiseLvl":names[i];bool digital=value(e,P_classic)>=.5f;if(i==P_model)name=digital?"LPF":"Model";if(i==P_saturate)name=digital?"DEGRADE":"Saturate";if(i==P_failure)name=digital?"HPF":"Failure";put((char*)ptr,name,8);}return 0;
 case 10:p->configure(opt);return 0;
 case 11:return 0;
 case 12:if(val&&!p->ready){try{p->activate();}catch(...){return 0;}}return 1;
 case 23:if(!ptr)return 0;p->snapshot(p->chunk.values);p->chunk.program=p->currentProgram;put(p->chunk.name,p->program,24);p->chunk.noiseEnabled=p->noiseEnabled.load();p->chunk.version=6;for(int k=0;k<3;++k)p->chunk.gate[k]=p->gate[k].load();*(void**)ptr=&p->chunk;return sizeof(Chunk);
 case 24:if(ptr&&(val==LEGACY_CHUNK_SIZE||val==V4_CHUNK_SIZE||val==sizeof(Chunk))){Chunk c;std::memcpy(&c,ptr,val);if(c.magic!=0x434c4354||((c.version!=3||val!=LEGACY_CHUNK_SIZE)&&(c.version!=4||val!=V4_CHUNK_SIZE)&&((c.version!=5&&c.version!=6)||val!=sizeof(Chunk)))||c.count!=PARAMS||c.program>=PROGRAMS||!std::memchr(c.name,0,24))return 0;
 if(c.version>=4&&(!std::isfinite(c.noiseEnabled)||(c.noiseEnabled!=0.f&&c.noiseEnabled!=1.f&&!(c.version>=5&&c.noiseEnabled==-1.f))))return 0;
 for(float v:c.values)if(!std::isfinite(v)||v<0||v>1)return 0;
 for(float v:c.gate)if(!std::isfinite(v)||v<0||v>1)return 0;
 if(c.version==5){c.gate[1]=std::clamp((c.gate[1]*10-1)/9,0.f,1.f);c.gate[2]*=10.f/15;}
 for(int k=0;k<PARAMS;++k)set(e,k,c.values[k]);p->noiseEnabled.store(c.version>=4?c.noiseEnabled:-1.f);for(int k=0;k<3;++k)p->gate[k].store(c.gate[k]);p->currentProgram=c.program;put(p->program,c.name,24);p->presetDisplayPending.store(true,std::memory_order_release);return 1;}return 0;
 case 25:if(ptr){struct Events{int32_t count;intptr_t reserved;void* events[1];};auto* events=static_cast<Events*>(ptr);if(events->count<0||events->count>1024)return 0;for(int n=0;n<events->count;++n){auto* ev=static_cast<unsigned char*>(events->events[n]);if(!ev)continue;int32_t type,size;std::memcpy(&type,ev,4);std::memcpy(&size,ev+4,4);if(type!=1||size<32||(ev[24]&0xf0)!=0xb0)continue;int cc=ev[25]&127,v=ev[26]&127;int key=-1;switch(cc){case 14:key=P_wow;break;case 15:key=P_volume;break;case 16:key=P_model;break;case 17:key=P_flutter;break;case 18:key=DRIVE;break;case 19:key=P_failure;break;case 72:key=P_classic;break;}if(key>=0){set(e,key,key==P_classic?(v>0?1.f:0.f):v/127.f);p->presetDisplayPending.store(true,std::memory_order_release);}}return 1;}return 0;
 case 26:if(i>=SILENCE_GATE&&i<=FADE_OUT)return 1;if(i==MODEL_SELECT||i==DRIVE||i==NOISE_SOUND||i==MECH_SOUND)return 1;return i>=0&&i<PARAMS&&i!=P_drop&&i!=P_snag&&i!=P_gain;
 case 29:if(i>=0&&i<PROGRAMS){put((char*)ptr,presetNames[i],24);return 1;}return 0;
 case 35:return 1;
 case 44:p->hostBypass.store(val!=0);return 1;
 case 45:put((char*)ptr,"Clif Tape",32);return 1;
 case 47:put((char*)ptr,"MagicStino",64);return 1;
 case 48:put((char*)ptr,"Clif Tape",64);return 1;
 case 49:return 200;
 case 51:if(ptr&&(!std::strcmp((const char*)ptr,"receiveVstEvents")||!std::strcmp((const char*)ptr,"receiveVstMidiEvent")))return 1;return 0;
 case 56:return 2400;
 default:return 0;
 }}
}
extern "C" __attribute__((visibility("default"))) AEffect* VSTPluginMain(audioMasterCallback host){try{auto*p=new Plugin(host);auto&e=p->fx;e.magic=0x56737450;e.dispatcher=dispatch;e.setParameter=set;e.getParameter=value;e.process=e.processReplacing=process;e.numPrograms=PROGRAMS;e.numParams=HOST_PARAMS;e.numInputs=e.numOutputs=2;e.flags=(1<<4)|(1<<5);e.object=p;e.uniqueID=ID;e.version=200;e.initialDelay=p->latency;e.ioRatio=1;return &e;}catch(...){return nullptr;}}
