// Independent motion synthesis informed by pitch measurements of the reference.
#pragma once
#include <cmath>
#include <cstdint>
#include <algorithm>
namespace clif {
inline float motionAmount(float value){float x=std::clamp(value,0.f,1.f),upper=std::max(0.f,(x-.5f)*2);return x*(1+.2f*upper*upper);}
class TapeMotion {
 double sr=48000,wowPhase=0,flutterPhase=0,flutterSide=0;
 float target=0,wander=0,slew=.001f;int remaining=0;uint32_t rng=0x61a3ef25;
 float random(){rng^=rng<<13;rng^=rng>>17;rng^=rng<<5;return float(rng>>8)/16777216.f;}
 public:
 void prepare(double rate){sr=rate;wowPhase=flutterPhase=flutterSide=0;target=wander=0;remaining=0;rng=0x61a3ef25;slew=float(1-std::exp(-1/(.35*sr)));}
 void advance(){if(--remaining<=0){target=random()*2-1;remaining=int(sr*(.7+random()*1.1));}wander+=(target-wander)*slew;
  constexpr double tau=6.283185307179586;
  wowPhase+=tau*(1.75+.85*wander)/sr;flutterPhase+=tau*(40.7+.35*wander)/sr;flutterSide+=tau*16/sr;
  if(wowPhase>tau)wowPhase-=tau;if(flutterPhase>tau)flutterPhase-=tau;if(flutterSide>tau)flutterSide-=tau;
 }
 float delaySeconds(float wow,float flutter,float offset)const{
  double slow=.85*std::sin(wowPhase+offset)+.15*std::sin(2*wowPhase+offset);
  double fast=.8*std::sin(flutterPhase+offset*1.3)+.2*std::sin(flutterSide+offset);
  return float(.0055*motionAmount(wow)*slow+.00015*motionAmount(flutter)*fast);
 }
};
}
