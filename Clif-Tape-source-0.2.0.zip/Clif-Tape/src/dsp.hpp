// Original Clif Tape DSP. No embedded processor, firmware or extracted tables.
#pragma once
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <vector>
#include "tone_models.hpp"
#include "motion.hpp"
namespace clif {
struct Stereo { float l=0,r=0; };
struct Controls {
 float wow=0,flutter=0,drive=0,failure=0,mix=.4f,volume=.5f;
 float digital=0,lowpass=0,highpass=0,degrade=0,spread=0,mono=0;
 float silenceGate=1,fadeIn=2,fadeOut=8;
 float hiss=0,mechanical=0,crackle=0; int model=0;
};
struct CrackleControl {float density,gain;};
inline CrackleControl crackleControl(float x){x=std::clamp(x,0.f,1.f);return {x<=.35f?.5f:x<=.5f?.5f+(x-.35f)/.15f*.5f:1.f+(x-.5f),std::min(x,.5f)*std::min(x,.5f)*.12f};}
class SilenceGate {
 double level=1;
 public:
 void reset(){level=1;}
 float tick(bool signal,bool enabled,float attack,float release,double rate){if(!enabled){level=1;return level;}float seconds=signal?attack:release;seconds=std::isfinite(seconds)?std::clamp(seconds,0.f,signal?10.f:15.f):0;double step=seconds>0?1/(rate*seconds):1;level=std::clamp(level+(signal?step:-step),0.,1.);if(level<1e-10)level=0;if(level>1-1e-10)level=1;return float(level);}
};
class DSP {
 static constexpr double pi=3.14159265358979323846;
 struct Channel {ToneModels models;BiquadState degradePre,degradePost,saturationBody;float previousSample=0;std::vector<float> delay; float mechDC=0,mechLow=0,mechHigh=0,mechChatter=0,noiseBrown=0,lp=0,hp=0,held=0,clock=0,crackle=0,crackleEnv=0,crackleLP=0,crackleHP=0,wear=1,target=1; uint32_t rng=1;};
 std::array<Channel,2> ch;
 double rate=44100,phase=0,fast=0,hum=0; size_t pos=0; int latency_=353;
 SilenceGate noiseGate;
 TapeMotion motion;
 BiquadCoefficients degradeFilter,bodyFilter;float bodyDb=0;
 Controls sm; bool first=true; float slew=.001f;
 uint32_t coefficientTick=0;float a=1,ha=0,drive=1,driveScale=1,hold=1,gain=1,crackleDecay=.99f,crackleAttack=.1f,crackleLow=.1f,crackleHigh=.1f,noiseBrownPole=.01f,mechLowPole=.1f,mechHighPole=.01f,mechDecay=.99f;
 static float valid(float x){return std::isfinite(x)?std::clamp(x,-8.f,8.f):0.f;}
 static float unit(float x){return std::isfinite(x)?std::clamp(x,0.f,1.f):0;}
 static float random(Channel& c){uint32_t x=c.rng;x^=x<<13;x^=x>>17;x^=x<<5;c.rng=x;return float(x>>8)*(1.f/16777216.f);}
 float read(const Channel& c,float delay)const {double at=double(pos)-delay;while(at<0)at+=c.delay.size();size_t i=size_t(at)%c.delay.size();float t=float(at-std::floor(at));return c.delay[i]*(1-t)+c.delay[(i+1)%c.delay.size()]*t;}
 public:
 void prepare(double sr){rate=std::clamp(sr,8000.,192000.);latency_=int(std::ceil(.008*rate));slew=float(1-std::exp(-1/(.02*rate)));for(int i=0;i<2;++i){ch[i]=Channel{};ch[i].models.prepare(rate);ch[i].delay.assign(size_t(.04*rate)+8,0);ch[i].rng=0x13579u+i*0x93821u;}pos=0;phase=fast=hum=0;motion.prepare(rate);noiseGate.reset();bodyDb=0;bodyFilter={};first=true;coefficientTick=0;mechLowPole=float(1-std::exp(-2*pi*2400/rate));mechHighPole=float(1-std::exp(-2*pi*240/rate));mechDecay=float(std::exp(-1/(.008*rate)));noiseBrownPole=float(1-std::exp(-2*pi*180/rate));crackleDecay=float(std::exp(-1/(.0025*rate)));crackleAttack=float(1-std::exp(-1/(.0004*rate)));crackleLow=float(1-std::exp(-2*pi*3200/rate));crackleHigh=float(1-std::exp(-2*pi*650/rate));}
 int latency()const{return latency_;}
 Stereo tick(Stereo input,Controls target,bool bypass=false){
  // The control struct is deliberately independent of plugin/firmware layouts.
#define SM(field) sm.field+=(unit(target.field)-sm.field)*(first?1.f:slew)
  SM(wow);SM(flutter);SM(drive);SM(failure);SM(mix);SM(volume);SM(digital);SM(lowpass);SM(highpass);SM(degrade);SM(spread);SM(mono);SM(hiss);SM(crackle);
#undef SM
  sm.mechanical+=(std::clamp(target.mechanical,-1.f,1.f)-sm.mechanical)*(first?1.f:slew);sm.model=std::clamp(target.model,0,12);first=false;
  float bodyTarget=sm.model==2?-2.5f:sm.model==3?-2.f:sm.model==5?-1.8f:0.f;
  bodyDb+=(bodyTarget*sm.drive*(1-sm.digital)-bodyDb)*slew;
  float in[2]={valid(input.l),valid(input.r)},out[2];
  float noiseEnvelope=noiseGate.tick(in[0]!=0||in[1]!=0,target.silenceGate>=.5f,target.fadeIn,target.fadeOut,rate);
  // Update expensive coefficients at control rate; audio and smoothing stay sample-rate.
  if((coefficientTick++ & 31)==0){
   bodyFilter=designFilter({3,480,.8,bodyDb},rate);
   float cutoff=20000*std::pow(.03f,sm.lowpass);
   cutoff=std::min(cutoff,float(rate*.45));a=float(1-std::exp(-2*pi*cutoff/rate));
   float hpHz=20*std::pow(100.f,sm.highpass);ha=float(1-std::exp(-2*pi*hpHz/rate));
   drive=1+9*sm.drive;driveScale=1/std::sqrt(drive);
   float virtualRate=320+31680*(1-sm.degrade);hold=float(rate)/std::min(float(rate),virtualRate);degradeFilter=designFilter({1,virtualRate*.38,.70710678,0},rate);gain=std::pow(4.f,2*sm.volume-1);
  }
  motion.advance();
  for(int c=0;c<2;++c){auto& s=ch[c];float x=in[c]*(1-sm.mono)+(in[0]+in[1])*.5f*sm.mono;s.delay[pos]=x;
   float dry=read(s,float(latency_));float offset=c*sm.spread*1.7f;
   float drift=motion.delaySeconds(sm.wow,sm.flutter,offset);
   float y=read(s,float(latency_)+float(rate)*drift);
   s.lp+=a*(y-s.lp);float saturated=y*(1-sm.drive)+sm.drive*std::tanh(y*drive)*driveScale;
   float tone=s.models.tick(saturated,sm.model)*(1-sm.digital)+s.lp*sm.digital;
   s.hp+=ha*(tone-s.hp);tone-=s.hp*sm.digital;
   float tape=s.saturationBody.tick(tone,bodyFilter);
   if(random(s)<sm.failure*sm.failure*float(7/rate))s.target=.1f+.9f*random(s);
   s.target+=(1-s.target)*float(1/(.1*rate));s.wear+=(s.target-s.wear)*float(1/(.003*rate));
   tape*=1-sm.failure+sm.failure*s.wear;
   // Bandwidth-limited sample-rate aging, rather than deep bit quantization.
   float filtered=s.degradePre.tick(tone,degradeFilter);
   s.clock+=1;if(s.clock>=hold){s.clock-=hold;float fraction=std::clamp(1-s.clock,0.f,1.f);s.held=s.previousSample+(filtered-s.previousSample)*fraction;}
   s.previousSample=filtered;
   float aged=s.degradePost.tick(s.held,degradeFilter);
   float agingBlend=std::min(1.f,sm.degrade*20.f);
   float digital=tone*(1-agingBlend)+aged*agingBlend;y=tape*(1-sm.digital)+digital*sm.digital;
   // Crackle has its own audible level; Failure adds event density rather than gating it.
   auto crackleShape=crackleControl(sm.crackle);
   if(random(s)<float((2+18*sm.failure)*.5f*crackleShape.density/rate))s.crackle=std::max(s.crackle,.4f+.6f*random(s));
   s.crackle*=crackleDecay;
   s.crackleEnv+=crackleAttack*(s.crackle-s.crackleEnv);
   float dust=random(s)*2-1;
   s.crackleLP+=crackleLow*(dust-s.crackleLP);
   s.crackleHP+=crackleHigh*(s.crackleLP-s.crackleHP);
   float crackle=(s.crackleLP-s.crackleHP)*s.crackleEnv*crackleShape.gain;
   float white=random(s)*2-1;
   // Dark, leaky-integrated noise at low levels; white fades in from 7 to 30%.
   s.noiseBrown+=noiseBrownPole*(white-s.noiseBrown);
   float brown=s.noiseBrown*std::sqrt((2-noiseBrownPole)/noiseBrownPole);
   float whiteBlend=std::clamp((sm.hiss-.07f)/.23f,0.f,1.f);
   float hiss=(brown*(1-whiteBlend)+white*whiteBlend)*sm.hiss*(.055f/3.f);
   // Independently synthesized mechanism texture: rolling whirr/chatter and
   // electrical buzz. High-passed noise and harmonics avoid a pure sub tone.
   float mechanismNoise=random(s)*2-1;
   s.mechLow+=mechLowPole*(mechanismNoise-s.mechLow);
   s.mechHigh+=mechHighPole*(s.mechLow-s.mechHigh);
   float texture=(s.mechLow-s.mechHigh)*2.f;
   if(random(s)<float(9/rate))s.mechChatter=.3f+.7f*random(s);
   s.mechChatter*=mechDecay;
   float whirr=float(.35*std::sin(fast*42+.7*std::sin(phase))+.18*std::sin(fast*83+.4*std::sin(fast)));
   float rolling=float(.65+.2*std::sin(fast*4)+.15*std::sin(fast*1.3));
   float motor=(whirr+texture*(.7f+s.mechChatter))*rolling;
   float buzz=float(.12*std::sin(hum)+.3*std::sin(3*hum)+.28*std::sin(5*hum)+.18*std::sin(7*hum)+.1*std::sin(11*hum));
   buzz+=texture*float(.2+.15*std::pow(std::sin(hum),2));
   float mechanism=sm.mechanical>=0?buzz:motor;
   s.mechDC+=mechHighPole*(mechanism-s.mechDC);
   float mech=(mechanism-s.mechDC)*std::abs(sm.mechanical)*(.025f/3.f);
   y=(y+(hiss+mech+crackle)*noiseEnvelope)*gain;
   out[c]=bypass?dry:dry*(1-sm.mix)+y*sm.mix;
   if(!std::isfinite(out[c]))out[c]=0;
  }
  phase+=2*pi*.37/rate;fast+=2*pi*7.3/rate;hum+=2*pi*50/rate;
  if(phase>2*pi)phase-=2*pi;if(fast>2*pi)fast-=2*pi;if(hum>2*pi)hum-=2*pi;
  pos=(pos+1)%ch[0].delay.size();return {out[0],out[1]};
 }
};
}
