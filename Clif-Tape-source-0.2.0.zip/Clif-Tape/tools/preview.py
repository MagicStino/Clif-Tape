from pathlib import Path
import sys,json,re
from PIL import Image,ImageDraw,ImageFont
root=Path(__file__).resolve().parent.parent
skin=root/'skin/MagicStino - VST - Clif Tape/Plugin Skins'
params=json.loads((root/'vst/params.json').read_text())
factory=json.loads((root/'presets/factory.json').read_text())[0]['values']
if '--digital' in sys.argv:factory['classic']=1
if '--mix-max' in sys.argv:factory['mix']=1
bounds_model=[0,20,39,58,78,97,116,136,155,174,194,213,232]
model_index=max(i for i,b in enumerate(bounds_model) if round(factory['model']*255)>=b)
factory['noise_sound']=1 if factory['noise']>=.25 else 0
factory['mech_sound']=1 if factory['noise']>=.25 and factory['hum']<.5 else 0
factory['drive']=factory['saturate']
factory.update(silence_gate=1,fade_in=1/9,fade_out=8/15)
factory.update(model_select=model_index/12,model_select_prev=0,model_select_next=0)
for p in params:
 v=factory[p['key']];p['default']=p['options'][round(v*(len(p['options'])-1))] if 'options' in p else v
def norm(p):return p['options'].index(p['default'])/(len(p['options'])-1) if 'options'in p else p['default']
def label(p):
 if p["key"]=="mechanical":
  v=p["default"]
  return "Silent" if abs(v-.5)<1/255 else f"{'VCR' if v<.5 else 'Hum'} {abs(v-.5)*200:.0f}"
 if p['key']=='mix':return f"{p['default']*100:.0f}%"
 if p['key']=='fade_in':return f"{1+9*p['default']:.1f} s"
 if p['key']=='fade_out':return f"{15*p['default']:.1f} s"
 return p['default'] if 'options'in p else f"{p['default']*100:.1f}"
t=json.loads((skin/'TUI.json').read_text())['pageData'];defs={x['key']:x['value'] for x in t['componentDefinitions']['localComponentDefinitions']}
bounds=lambda c:[round(float(n))for n in c['bounds']['bounds'].split()]
font='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
for idx,tab in enumerate(t['tabs']):
 im=Image.new('RGB',(1280,628));d=ImageDraw.Draw(im)
 for c in defs[tab['componentName']]['componentsData']:
  visible=True
  for handle in c['bounds'].get('additionalInvalidatingHandles',[]):
   m=re.fullmatch(r'IndexedEnabling/(\d+)/(\d+)/Parameter (\d+)',handle)
   if m:
    option,count,param=map(int,m.groups());visible &= round(norm(params[param])*(count-1))==option
  if not visible:continue
  cd=c['componentData'];x,y,w,h=bounds(c)
  if cd['type']=='Image':
   a=Image.open(skin/cd['data']['image']).convert('RGBA');im.paste(a,(x,y),a);continue
  maps=c.get('handle remapping',{}).get('map',[]);m=next((re.search(r'Parameter (\d+)',z['value']) for z in maps if re.search(r'Parameter (\d+)',z['value'])),None)
  p=params[int(m[1])] if m else params[0]
  for s in defs[cd['type']]['componentsData']:
   sd=s['componentData'];sx,sy,sw,sh=bounds(s);data=sd['data'];kind=sd['type']
   if kind=='Image':a=Image.open(skin/data['image']).convert('RGBA');im.paste(a,(x+sx,y+sy),a)
   elif kind=='Knob':
    a=Image.open(skin/data['filmStrip']).convert('RGBA');fh=sh;count=a.height//fh;k=round(norm(p)*(count-1));a=a.crop((0,k*fh,a.width,(k+1)*fh));im.paste(a,(x+sx,y+sy),a)
   elif kind=='Button':
    count=data.get('numButtonsInGroup',1);selected=(norm(p)>=.5) if count==1 else round(norm(p)*(count-1))==data.get('buttonId',0)
    file=data.get('onImage' if selected else 'offImage');
    if file:a=Image.open(skin/file).convert('RGBA');im.paste(a,(x+sx,y+sy),a)
   elif kind=='Label':
    if int(data['textStyle']['font']['height'])<=0:continue
    txt=cd.get('name','') if data.get('type')=='Name' else label(p)
    ts=data['textStyle'];f=ImageFont.truetype(font,int(ts['font']['height']));rgb='#'+ts['colour'][-6:];box=d.textbbox((0,0),txt,font=f);tw,th=box[2]-box[0],box[3]-box[1]
    tx=sw-tw if 'right' in ts.get('justification','').lower() else (sw-tw)/2
    d.text((x+sx+tx-box[0],y+sy+(sh-th)/2-box[1]),txt,font=f,fill=rgb)
 im.save(root/f'docs/panel-{idx}{"-digital" if "--digital" in sys.argv else ""}.png')
print('Rendered native-skin layout previews at default control values.')
