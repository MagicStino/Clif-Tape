from pathlib import Path
import json,copy,xml.etree.ElementTree as E
r=Path(__file__).resolve().parent.parent;skin=r/'skin/MagicStino - VST - Clif Tape/Plugin Skins'
p=skin/'TUI.json';doc=json.loads(p.read_text());page=doc['pageData'];defs=page['componentDefinitions']['localComponentDefinitions'];lookup={x['key']:x['value'] for x in defs}
def bounds(s,focus='No',when=[]):return dict(version=2,acceptsHWFocus=focus,showWhenDataModelInvalid='Hide',whenVisible='Always',boundsType='Absolute',bounds=s,additionalInvalidatingHandles=when)
def node(typ,pos,param=None,when=[],focus='Yes'):
 return {'version':2,'componentData':{'version':1,'name':'','type':typ,'data':{'version':1,'handleName':'Data'}},'handle remapping':{'version':1,'map':([] if param is None else [{'key':'Data','value':f'Parameter {param}'}])},'bounds':bounds(pos,focus,when)}
knob=next(k for k in lookup if k.startswith('shKnob42_'))
dim=copy.deepcopy(lookup[knob]);dim['actions']=[];dim['ignoreMousePresses']=True
for part in dim['componentsData']:
 d=part['componentData']['data']
 if part['componentData']['type']=='Label':d['textStyle']['colour']='ff888888'
defs[:]=[d for d in defs if d['key'] not in ['GateFadeDisabled','Silence Gate|Silence Gate']]
defs.append({'key':'GateFadeDisabled','value':dim})
toggle=next(k for k in lookup if k.startswith('shToggle_19682151'))
# Existing full-face switch artwork and interaction are retained.
gateToggle=copy.deepcopy(lookup[toggle]) # Native Button handles touch; parent only focuses Q-Link.
defs[:]=[d for d in defs if d['key']!='SilenceGateSwitch'];defs.append({'key':'SilenceGateSwitch','value':gateToggle})
parts=[{'version':2,'componentData':{'version':1,'name':'Background','type':'Image','data':{'version':2,'imageType':'Regular','colour':'0','image':'silence-gate-bg.png'}},'handle remapping':{'version':1,'map':[]},'bounds':bounds('0 0 1280 628')}]
parts.append(node('SilenceGateSwitch','232 290 136 64',24))
for param,x in [(25,585),(26,935)]:
 parts.append(node(knob,f'{x} 272 130 126',param,['IndexedEnabling/1/2/Parameter 24']))
 parts.append(node('GateFadeDisabled',f'{x} 272 130 126',param,['IndexedEnabling/0/2/Parameter 24'],'No'))
parts+=copy.deepcopy(lookup['Tape Noise|Tape Noise']['componentsData'][-2:])
root=copy.deepcopy(lookup['Tape Noise|Tape Noise']);root['componentsData']=parts;defs.append({'key':'Silence Gate|Silence Gate','value':root})
page['tabs']=[t for t in page['tabs'] if t['tabName']!='Silence Gate'];tab=copy.deepcopy(page['tabs'][0]);tab.update(tabName='Silence Gate',fnKeyIndex=3,componentName='Silence Gate|Silence Gate');page['tabs'].append(tab);p.write_text(json.dumps(doc,indent=2)+'\n')
for p in skin.glob('Q-Link*.json'):
 q=json.loads(p.read_text());maps=q['Screen Mode Q-Links']['map'];maps[:]=[m for m in maps if m['Tab']!=4];m=copy.deepcopy(maps[-1]);m['Tab']=4;m['Q-Links']={k:-1 for k in m['Q-Links']};m['Q-Links'].update({'Q-Link 13':24,'Q-Link 9':25,'Q-Link 5':26,'Q-Link 14':6,'Q-Link 10':1});maps.append(m);p.write_text(json.dumps(q,indent=2)+'\n')
p=r/'vst/params.json';params=json.loads(p.read_text());params=[x for x in params if x['key'] not in ['silence_gate','fade_in','fade_out']];params += [dict(key='silence_gate',name='Silence Gate',default='On',options=['Off','On']),dict(key='fade_in',name='Fade In',default=1/9,min=0,max=1),dict(key='fade_out',name='Fade Out',default=8/15,min=0,max=1)];p.write_text(json.dumps(params,indent=2)+'\n')
p=r/'vst/params.lock';lines=p.read_text().splitlines();p.write_text('\n'.join([x for x in lines if x not in ['silence_gate','fade_in','fade_out']]+['silence_gate','fade_in','fade_out'])+'\n')
ns='http://www.w3.org/2000/svg';E.register_namespace('',ns);bg=E.parse(r/'vst/art/base.svg').getroot()
def text(x,y,s,size=24):
 e=E.SubElement(bg,'{'+ns+'}text',{'x':str(x),'y':str(y),'text-anchor':'middle','class':'label','style':f'font-size:{size}px'});e.text=s
text(640,142,'SILENCE GATE',28);text(640,185,'Controls Crackle, Noise and Mechanical',23)
for x,s in [(300,'ON / OFF'),(650,'FADE IN'),(1000,'FADE OUT')]:text(x,250,s)
text(640,439,'Silence fades them out. Returning input fades them in.',21)
noise=E.parse(r/'vst/art/noise.svg').getroot()
for e in list(noise)[-5:]:bg.append(copy.deepcopy(e))
E.ElementTree(bg).write(r/'vst/art/silence-gate.svg',encoding='unicode')
print('Generated native gate screen, disabled fade controls and Q-Link map.')
