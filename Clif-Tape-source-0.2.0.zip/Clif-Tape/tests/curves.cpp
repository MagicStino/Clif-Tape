#include "../src/dsp.hpp"
#include "measured_curves.hpp"
#include <complex>
#include <cassert>
#include <iostream>
#include <vector>
int main(){
 for(int m=0;m<13;++m){clif::ToneModels tone;tone.prepare(48000);for(int n=0;n<5000;++n)tone.tick(0,m);std::vector<float> impulse(24000);for(int n=0;n<24000;++n)impulse[n]=tone.tick(n==0?1.f:0.f,m);double squared=0,maximum=0;
 for(int f=0;f<63;++f){auto step=std::polar(1.,-6.283185307179586*measuredFrequencies[f]/48000);std::complex<double> phase=1,sum=0;for(float y:impulse){sum+=double(y)*phase;phase*=step;}double db=20*std::log10(std::max(1e-12,std::abs(sum))),delta=std::max(-60.,db)-std::max(-60.,measuredDb[m][f]);squared+=delta*delta;maximum=std::max(maximum,std::abs(delta));}assert(std::sqrt(squared/63)<.6);assert(maximum<2.);}
 auto lo=clif::crackleControl(.35),mid=clif::crackleControl(.5),hi=clif::crackleControl(1);assert(std::abs(lo.density-.5)<1e-6&&std::abs(mid.density-1)<1e-6&&std::abs(hi.density-1.5)<1e-6);assert(mid.gain==hi.gain&&clif::crackleControl(0).gain==0);assert(clif::crackleControl(.1).density==lo.density);
 // A quiet signal must survive DEGRADE proportionally: no low-bit quantization gate.
 for(float depth:{.25f,.5f,.75f,1.f}){clif::DSP a,b;a.prepare(48000);b.prepare(48000);clif::Controls c;c.digital=1;c.degrade=depth;c.mix=1;double err=0,signal=0;for(int n=0;n<96000;++n){float x=.05f*std::sin(n*6.283185307179586*997/48000);float y=a.tick({x,x},c).l,z=b.tick({x*.01f,x*.01f},c).l;err+=(z-.01*y)*(z-.01*y);signal+=y*y;}assert(signal>1e-8);assert(err<signal*1e-12);}
 std::cout<<"PASS: 13 measured model curves at 63 frequencies (<0.6 dB RMS, <2 dB max), specified crackle density/gain, linear low-level DEGRADE\n";
}
