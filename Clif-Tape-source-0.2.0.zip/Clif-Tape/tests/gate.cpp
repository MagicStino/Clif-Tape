#include "../src/dsp.hpp"
#include <cassert>
#include <iostream>
int main(){
 for(double sr:{8000.,44100.,48000.,96000.,192000.}){clif::SilenceGate g;float v=1;for(int i=0;i<int(sr*5);++i)v=g.tick(false,true,1,10,sr);assert(std::abs(v-.5f)<1e-5);for(int i=0;i<int(sr*5);++i)v=g.tick(false,true,1,10,sr);assert(v==0);for(int i=0;i<int(sr/2);++i)v=g.tick(true,true,1,10,sr);assert(std::abs(v-.5f)<1e-5);for(int i=0;i<int(sr/2);++i)v=g.tick(true,true,1,10,sr);assert(v==1);assert(g.tick(false,true,0,0,sr)==0);assert(g.tick(false,false,1,10,sr)==1);}
 for(int source=0;source<3;++source){clif::DSP d;d.prepare(48000);clif::Controls c;c.mix=1;c.fadeOut=.1;c.hiss=source==0;c.mechanical=source==1;c.crackle=source==2;double energy=0;for(int i=0;i<96000;++i){auto y=d.tick({},c);if(i>9600)assert(y.l==0&&y.r==0);energy+=y.l*y.l;}if(source<2)assert(energy>0);c.silenceGate=0;energy=0;for(int i=0;i<96000;++i){auto y=d.tick({},c);energy+=y.l*y.l;}assert(energy>0);}
 clif::SilenceGate longGate;float v=1;for(int i=0;i<720000;++i)v=longGate.tick(false,true,2,15,48000);assert(v==0);for(int i=0;i<96000;++i)v=longGate.tick(true,true,2,8,48000);assert(v==1);
 clif::DSP a,b;a.prepare(48000);b.prepare(48000);clif::Controls c;c.mix=1;c.fadeOut=0;auto off=c;off.silenceGate=0;for(int i=0;i<96000;++i){float x=i<10000||i>30000?.2f*std::sin(i*.05f):0;auto y=a.tick({x,x},c),z=b.tick({x,x},off);assert(y.l==z.l&&y.r==z.r);}
 clif::DSP d;d.prepare(48000);c.hiss=1;c.fadeIn=0;for(int i=0;i<100;++i)d.tick({},c);double energy=0;for(int i=0;i<1000;++i){auto y=d.tick({0,1e-20f},c);energy+=y.l*y.l;}assert(energy>0);
 std::cout<<"PASS: gate timing at five sample rates, all three textures silenced, Off restores textures, music unaffected, either input opens\n";
}
