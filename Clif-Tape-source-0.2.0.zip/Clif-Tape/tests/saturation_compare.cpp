#include <initializer_list>
#include "../src/vst2.hpp"
#include <cmath>
#include <cassert>
#include <cstdio>
#include <dlfcn.h>
double render(const char*path,int model,float drive){auto lib=dlopen(path,RTLD_NOW);assert(lib);auto make=(AEffect*(*)(audioMasterCallback))dlsym(lib,"VSTPluginMain");auto e=make(nullptr);e->dispatcher(e,0,0,0,nullptr,0);e->dispatcher(e,10,0,0,nullptr,48000);for(int i=0;i<18;++i)e->setParameter(e,i,0);e->setParameter(e,1,.5);e->setParameter(e,6,1);e->setParameter(e,18,model/12.f);e->setParameter(e,21,drive);float l[256],r[256],a[256],b[256];float*in[]={l,r},*out[]={a,b};double si=0,co=0;for(int k=0;k<400;++k){for(int i=0;i<256;++i)l[i]=r[i]=.1*std::sin((k*256+i)*6.283185307179586*480/48000);e->processReplacing(e,in,out,256);if(k>=200)for(int i=0;i<256;++i){double t=(k*256+i)*6.283185307179586*480/48000;si+=a[i]*std::sin(t);co+=a[i]*std::cos(t);}}e->dispatcher(e,1,0,0,nullptr,0);dlclose(lib);return std::hypot(si,co);}
int main(int argc,char**argv){assert(argc==3);for(int m:{0,2,3,5,6})for(float d:{0.f,.75f}){double change=20*std::log10(render(argv[2],m,d)/render(argv[1],m,d));printf("model %d drive %.2f: %.3f dB\n",m,d,change);if(d==0||m==0||m==6)assert(std::abs(change)<.01);else assert(change< -1&&change> -2.1);}puts("PASS: modest targeted body reduction, zero-drive and other models unchanged");}
