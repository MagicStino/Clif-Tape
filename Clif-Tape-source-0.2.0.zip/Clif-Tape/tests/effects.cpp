#include "../src/vst2.hpp"
#include <dlfcn.h>
#include <cassert>
#include <cmath>
#include <iostream>
#include <vector>
#include <utility>
using Settings=std::vector<std::pair<int,float>>;
using Entry=AEffect*(*)(audioMasterCallback);
intptr_t echo(AEffect* e,int32_t op,int32_t i,intptr_t,void*,float v){if(op==0)e->setParameter(e,i,v);return 0;}
std::vector<float> render(Entry entry,Settings settings,int signal=0,bool bypass=false){
 auto e=entry(echo);assert(e);e->dispatcher(e,0,0,0,nullptr,0);e->dispatcher(e,10,0,0,nullptr,48000);
 for(int i=0;i<18;++i)e->setParameter(e,i,0);e->setParameter(e,1,.5);e->setParameter(e,6,1);e->setParameter(e,15,.5);e->setParameter(e,22,0);e->setParameter(e,23,0);
 for(auto kv:settings)e->setParameter(e,kv.first,kv.second);
 e->dispatcher(e,44,0,bypass,nullptr,0);
 std::vector<float> result;float l[256],r[256],a[256],b[256];float* in[]={l,r};float* out[]={a,b};
 for(int block=0;block<750;++block){for(int i=0;i<256;++i){int n=block*256+i;float x=signal==1?0:.3*std::sin(n*6.283185307179586*(signal==2?80:6000)/48000);l[i]=x;r[i]=signal==3?-x:x;}e->processReplacing(e,in,out,256);if(block>40)for(int i=0;i<256;++i){assert(std::isfinite(a[i])&&std::isfinite(b[i]));result.push_back(a[i]);result.push_back(b[i]);}}
 e->dispatcher(e,1,0,0,nullptr,0);return result;
}
double energy(const std::vector<float>&a){double e=0;for(float x:a)e+=x*x;return e;}
double diff(const std::vector<float>&a,const std::vector<float>&b){double e=0;for(size_t i=0;i<a.size();++i)e+=(a[i]-b[i])*(a[i]-b[i]);return e;}
double stereo(const std::vector<float>&a){double e=0;for(size_t i=0;i<a.size();i+=2)e+=(a[i]-a[i+1])*(a[i]-a[i+1]);return e;}
int main(int argc,char**argv){assert(argc==2);auto lib=dlopen(argv[1],RTLD_NOW);assert(lib);auto entry=(Entry)dlsym(lib,"VSTPluginMain");assert(entry);
 auto base=render(entry,{});for(int p:{0,3,21,5})assert(diff(base,render(entry,{{p,1}}))>1);
 for(int m=1;m<=12;++m)assert(diff(base,render(entry,{{18,m/12.f}}))>1);
 auto dig=render(entry,{{8,1}});assert(energy(render(entry,{{8,1},{18,1}}))<energy(dig)*.1);assert(diff(dig,render(entry,{{8,1},{21,1}}))>1);
 assert(energy(render(entry,{{8,1},{5,1}},2))<energy(render(entry,{{8,1}},2))*.1);
 for(int mode:{0,1}){assert(stereo(render(entry,{{8,float(mode)},{0,.8},{10,0}}))<1e-8);assert(stereo(render(entry,{{8,float(mode)},{0,.8},{10,1}}))>1);}
 assert(energy(render(entry,{{9,1}},3))<1e-8);assert(energy(render(entry,{},3))>100);
 assert(energy(render(entry,{{14,1},{22,0}},1))==0);assert(energy(render(entry,{{14,1},{22,1}},1))>1);
 for(float mech:{0.f,1.f}){assert(energy(render(entry,{{15,mech},{23,0}},1))==0);auto sound=render(entry,{{15,mech},{23,1}},1);assert(energy(sound)>.01);
 double low=0,total=energy(sound),lp=0,peak=0;for(size_t i=0;i<sound.size();i+=2){lp+=.012*(sound[i]-lp);low+=lp*lp;peak=std::max(peak,double(std::abs(sound[i])));}assert(low*2<total*.5);assert(peak<.02);}
 assert(energy(render(entry,{{15,.5},{23,1}},1))==0);assert(energy(render(entry,{{16,1}},1))>.001);
 auto fullNoise=render(entry,{{14,1},{22,1}},1);
 double peak=0;for(float x:fullNoise)peak=std::max(peak,double(std::abs(x)));assert(peak<=.055/3+1e-6);
 auto darkness=[](const std::vector<float>& x){double d=0;for(size_t i=2;i<x.size();++i)d+=(x[i]-x[i-2])*(x[i]-x[i-2]);return d/energy(x);};
 auto darkNoise=render(entry,{{14,.07},{22,1}},1),middleNoise=render(entry,{{14,.185},{22,1}},1),whiteNoise=render(entry,{{14,.3},{22,1}},1);
 assert(darkness(darkNoise)<darkness(middleNoise));assert(darkness(middleNoise)<darkness(whiteNoise));assert(darkness(darkNoise)<darkness(whiteNoise)*.1);
 auto dry=render(entry,{{6,0},{18,1}}),wet=render(entry,{{6,1},{18,1}}),mix=render(entry,{{6,.4},{18,1}});
 for(size_t i=0;i<mix.size();++i)assert(std::abs(mix[i]-(dry[i]*.6+wet[i]*.4))<1e-6);
 assert(diff(base,render(entry,{{0,1},{16,1},{21,1}},0,true))<1e-8);
 assert(std::abs(energy(render(entry,{{1,1}}))/energy(base)-16)<.001);
 std::cout<<"PASS: actual host audio paths: 13 Tape models, wow, flutter, saturation, failure, Digital LP/HP/degrade, mono, stereo spread in both modes, hiss and mechanical switches, crackle, Mix, volume and bypass\n";dlclose(lib);
}
