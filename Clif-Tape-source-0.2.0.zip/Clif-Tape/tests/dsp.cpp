#include "../src/dsp.hpp"
#include <cassert>
#include <iostream>
#include <limits>
#include <chrono>
using namespace clif;
double energy(Controls c,bool stereo=false){DSP d;d.prepare(48000);double sum=0;for(int i=0;i<96000;++i){float x=.2f*std::sin(i*.0576);auto y=d.tick({x,x},c);if(i>10000)sum+=stereo?std::pow(y.l-y.r,2):std::pow(y.l,2);}return sum;}
int main(){
 for(double sr:{8000.,44100.,48000.,96000.,192000.}){DSP d;d.prepare(sr);Controls c;c.mix=0;for(int i=0;i<d.latency()+10;++i){auto y=d.tick({i==0?1.f:0.f,i==0?-.5f:0.f},c);assert(std::abs(y.l-(i==d.latency()?1:0))<1e-6);assert(std::abs(y.r-(i==d.latency()?-.5f:0))<1e-6);}}
 Controls c;c.mix=1;c.volume=.5;assert(energy(c)>100);auto base=energy(c);c.digital=1;c.degrade=1;assert(std::abs(energy(c)-base)>1);c={};c.mix=1;c.wow=.8;c.spread=1;assert(energy(c,true)>1);c.spread=0;assert(energy(c,true)<1e-8);
 DSP d;d.prepare(48000);c={};c.mix=1;c.crackle=1;c.silenceGate=0;double noise=0;for(int i=0;i<480000;++i){auto y=d.tick({},c);noise+=y.l*y.l;}assert(noise>.01);
 for(int i=0;i<50000;++i){c.digital=(i/777)%2;c.degrade=1;c.model=(i/555)%13;c.hiss=1;c.drive=1;c.mechanical=1;c.failure=1;auto y=d.tick({i%11? .9f:std::numeric_limits<float>::quiet_NaN(),-.9f},c);assert(std::isfinite(y.l)&&std::isfinite(y.r));assert(std::abs(y.l)<16&&std::abs(y.r)<16);}
 DSP dust;dust.prepare(48000);Controls texture;texture.mix=1;texture.crackle=1;texture.silenceGate=0;texture.failure=.5;double peak=0,total=0;for(int i=0;i<480000;++i){auto y=dust.tick({},texture);peak=std::max(peak,double(std::abs(y.l)));total+=y.l*y.l;}assert(peak<.08&&total>.001);
 std::cout<<"PASS: latency/dry across five sample rates, independent degradation, spread, crackle and finite automation stress\n";
}
