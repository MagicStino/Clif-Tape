#include "../src/vst2.hpp"
#include <dlfcn.h>
#include <cassert>
#include <cmath>
#include <cstring>
#include <vector>
#include <iostream>
static int notifications=0;
intptr_t host(AEffect*e,int32_t op,int32_t i,intptr_t,void*,float v){if(op==0){++notifications;e->setParameter(e,i,v);}return 0;}
int main(int argc,char**argv){assert(argc==2);auto lib=dlopen(argv[1],RTLD_NOW);if(!lib){std::cerr<<dlerror();return 1;}auto main=(AEffect*(*)(audioMasterCallback))dlsym(lib,"VSTPluginMain");assert(main);auto e=main(host);assert(e&&e->uniqueID==0x436c4c43&&e->numParams==27);assert(e->dispatcher(e,0,0,0,nullptr,0));e->dispatcher(e,10,0,0,nullptr,48000);
 assert(std::abs(e->getParameter(e,14)-.1f)<1e-6);assert(e->getParameter(e,22)==0);
 float l[256]{},r[256]{},a[256]{},b[256]{};float* in[]={l,r};float* out[]={a,b};for(int i=0;i<256;++i)l[i]=r[i]=.1f*std::sin(i*.1f);
 e->setParameter(e,8,0);e->setParameter(e,2,0);e->setParameter(e,20,1);
 assert(std::abs(e->getParameter(e,18)-1.f/12)<1e-6); // GUI reads before the next audio block
 for(int k=0;k<=12;++k){e->setParameter(e,18,k/12.f);assert(std::abs(e->getParameter(e,2)-k/12.f)<1e-6);e->processReplacing(e,in,out,256);assert(std::abs(e->getParameter(e,18)-k/12.f)<1e-6);}
 for(int p=0;p<e->numPrograms;++p){assert(e->dispatcher(e,2,0,p,nullptr,0));e->processReplacing(e,in,out,256);for(float x:a)assert(std::isfinite(x));}assert(notifications>0);
 e->setParameter(e,8,1);e->setParameter(e,21,.75);e->processReplacing(e,in,out,256);assert(std::abs(e->getParameter(e,21)-.75)<1e-6);e->setParameter(e,22,1);e->setParameter(e,23,0);assert(e->getParameter(e,22)==1&&e->getParameter(e,23)==0);
 void* chunk=nullptr;auto size=e->dispatcher(e,23,0,0,&chunk,0);std::vector<char> saved((char*)chunk,(char*)chunk+size);e->setParameter(e,21,0);assert(e->dispatcher(e,24,0,size,saved.data(),0));assert(std::abs(e->getParameter(e,21)-.75)<1e-6);assert(size==128);e->setParameter(e,24,1);e->setParameter(e,25,.3f);e->setParameter(e,26,.7f);e->setParameter(e,24,0);e->setParameter(e,25,.9f);assert(std::abs(e->getParameter(e,25)-.3f)<1e-6);size=e->dispatcher(e,23,0,0,&chunk,0);saved.assign((char*)chunk,(char*)chunk+size);e->setParameter(e,24,1);assert(e->dispatcher(e,24,0,size,saved.data(),0));assert(e->getParameter(e,24)==0&&std::abs(e->getParameter(e,25)-.3f)<1e-6);for(int version:{3,4}){auto old=saved;uint32_t ver=version;std::memcpy(old.data()+4,&ver,4);float noise=0;std::memcpy(old.data()+112,&noise,4);assert(e->dispatcher(e,24,0,version==3?112:116,old.data(),0));assert(e->getParameter(e,24)==1&&std::abs(e->getParameter(e,25)-1.f/9)<1e-6&&std::abs(e->getParameter(e,26)-8.f/15)<1e-6);}auto v5=saved;uint32_t version5=5;std::memcpy(v5.data()+4,&version5,4);float oldGate[3]={0,.2f,.8f};std::memcpy(v5.data()+116,oldGate,12);assert(e->dispatcher(e,24,0,128,v5.data(),0));assert(e->getParameter(e,24)==0);assert(std::abs(e->getParameter(e,25)-1.f/9)<1e-6);assert(std::abs(e->getParameter(e,26)-8.f/15)<1e-6);e->processReplacing(e,in,out,256);assert(e->getParameter(e,24)==0);e->setParameter(e,24,1);char label[8]{};for(int k=25;k<=26;++k){e->setParameter(e,k,0);e->dispatcher(e,7,k,0,label,0);assert(!std::strcmp(label,k==25?"1.0 s":"0.0 s"));e->setParameter(e,k,1);e->dispatcher(e,7,k,0,label,0);assert(!std::strcmp(label,k==25?"10.0 s":"15.0 s"));}saved[0]^=1;assert(!e->dispatcher(e,24,0,size,saved.data(),0));e->dispatcher(e,1,0,0,nullptr,0);dlclose(lib);std::cout<<"PASS: native host load, 15 presets, UI echo, positive DEGRADE, independent switches and state validation\n";}
