#include "../src/motion.hpp"
#include <cassert>
#include <iostream>
int main(){
 assert(clif::motionAmount(0)==0);assert(clif::motionAmount(.25f)==.25f);assert(clif::motionAmount(.5f)==.5f);assert(std::abs(clif::motionAmount(1)-1.2f)<1e-6);
 for(double sr:{8000.,44100.,48000.,96000.,192000.}){clif::TapeMotion a,b;a.prepare(sr);b.prepare(sr);float previous=0;for(int i=0;i<int(sr*3);++i){a.advance();b.advance();float d=a.delaySeconds(1,1,1.7);assert(std::isfinite(d)&&std::abs(d)<.007);if(i>0)assert(std::abs(d-previous)<.0002);assert(d==b.delaySeconds(1,1,1.7));assert(a.delaySeconds(0,0,0)==0);previous=d;}}
 for(int kind=0;kind<2;++kind){double rms[2]{};for(int level=0;level<2;++level){clif::TapeMotion m;m.prepare(48000);float amount=level?1:.5,prev=0;double sum=0;int count=0;for(int n=0;n<960000;++n){m.advance();float d=m.delaySeconds(kind?0:amount,kind?amount:0,0);double cents=1200*std::log2(1-(d-prev)*48000);if(n>96000){sum+=cents*cents;++count;}prev=d;}rms[level]=std::sqrt(sum/count);}assert(rms[0]>(kind?15:25)&&rms[0]<(kind?23:42));assert(rms[1]/rms[0]>2.3&&rms[1]/rms[0]<2.5);}
 std::cout<<"PASS: motion range, smoothness, determinism and zero settings at five sample rates; reference-scale pitch depth and expressive upper half\n";
}
